interface ProgressBarProps {
  value: number;
  label?: string;
}

/**
 * A simple horizontal progress bar. Accepts a value between 0 and 1 and
 * optionally displays a label showing the percentage.
 */
export default function ProgressBar({ value, label }: ProgressBarProps) {
  const percentage = Math.min(Math.max(value, 0), 1) * 100;
  return (
    <div className="w-full h-3 bg-gray-300 dark:bg-gray-700 rounded-md overflow-hidden">
      <div
        className="h-full bg-primary transition-width duration-300"
        style={{ width: `${percentage}%` }}
      />
      {label && (
        <span className="block text-xs mt-1 text-right text-gray-600 dark:text-gray-400">
          {label}
        </span>
      )}
    </div>
  );
}