"use client";

import { useAutomation } from '../hooks/useAutomation';

/**
 * AutomationRunner is a simple component that invokes the useAutomation
 * hook. Including this component in the root layout ensures that
 * scheduled tasks run in the background across all pages. It renders
 * nothing to the DOM.
 */
export default function AutomationRunner() {
  useAutomation();
  return null;
}