"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  HomeIcon,
  WalletIcon,
  Building2Icon,
  ClipboardIcon,
  LightningBoltIcon,
  BarChartIcon,
  GearIcon,
  PlugIcon,
  ChatBubbleIcon,
} from '@radix-ui/react-icons';
import clsx from 'clsx';

/**
 * A simple horizontal navigation bar that appears at the top of the
 * application. Each navigation item highlights when active. Icons are
 * pulled from the Radix UI icon set. Adjust or replace icons as
 * needed.
 */
const navItems = [
  { href: '/', label: 'Home', Icon: HomeIcon },
  { href: '/money', label: 'Money', Icon: WalletIcon },
  { href: '/house', label: 'House', Icon: Building2Icon },
  { href: '/tasks', label: 'Tasks', Icon: ClipboardIcon },
  { href: '/opportunities', label: 'Opportunities', Icon: LightningBoltIcon },
  { href: '/trading', label: 'Trading', Icon: BarChartIcon },
  { href: '/settings', label: 'Settings', Icon: GearIcon },
  { href: '/connections', label: 'Connections', Icon: PlugIcon },
  { href: '/chat', label: 'Chat', Icon: ChatBubbleIcon },
];

export default function NavBar() {
  const pathname = usePathname();
  return (
    <nav className="flex gap-2 md:gap-4 items-center justify-between p-4 bg-card-light dark:bg-card-dark shadow-card rounded-b-lg">
      {navItems.map(({ href, label, Icon }) => {
        const active = pathname === href || (href !== '/' && pathname?.startsWith(href));
        return (
          <Link key={href} href={href} className="flex flex-col items-center flex-1">
            <Icon
              className={clsx('w-6 h-6 mb-1', {
                'text-primary': active,
                'text-gray-500 dark:text-gray-400': !active,
              })}
            />
            <span className={clsx('text-xs font-medium', {
              'text-primary': active,
              'text-gray-600 dark:text-gray-400': !active,
            })}>{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}