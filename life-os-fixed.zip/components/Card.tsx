import { ReactNode } from 'react';
import clsx from 'clsx';

interface CardProps {
  title?: string;
  children?: ReactNode;
  className?: string;
}

/**
 * A reusable card component with rounded corners and subtle shadow. It
 * automatically adapts to light and dark mode by using the Tailwind
 * color palette defined in tailwind.config.js. An optional title can
 * be displayed at the top.
 */
export default function Card({ title, children, className }: CardProps) {
  return (
    <div
      className={clsx(
        // Increase padding to give cards more breathing room. This
        // helps the UI feel less cramped and more premium.
        'bg-card-light dark:bg-card-dark rounded-lg shadow-card p-6',
        className
      )}
    >
      {title && (
        <h3
          // Increase the default card title size and weight. Larger titles
          // improve the visual hierarchy and make section headings easier
          // to scan at a glance.
          className="text-xl font-bold mb-3"
        >
          {title}
        </h3>
      )}
      {children}
    </div>
  );
}