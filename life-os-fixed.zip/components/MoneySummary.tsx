"use client";

import { useData } from '../app/context';
import Card from './Card';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';

/**
 * Displays a snapshot of the user's financial situation. It shows total
 * monthly income and expenses, weekly budget vs spending, safe-to-spend
 * amount, and a small bar chart comparing budgeted vs actual expenses
 * for each category. The card encourages at-a-glance insight into
 * finances without feeling like a spreadsheet.
 */
export default function MoneySummary() {
  const { money } = useData();
  // Prepare data for bar chart: each expense category with budget and actual
  const chartData = money.expenses.map((e) => ({ name: e.category, Budget: e.budget, Actual: e.actual }));
  // Determine if weekly spending exceeds the budget
  const overspending = money.weeklySpending - money.weeklyBudget;
  const status = overspending > 0 ? 'Overspending' : 'On track';
  const statusColor = overspending > 0 ? 'text-red-500' : 'text-green-500';
  return (
    <Card title="Money Snapshot" className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-gray-500">Monthly Income</p>
          <p className="text-2xl font-bold">${money.totalMonthlyIncome.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Monthly Expenses</p>
          <p className="text-2xl font-bold">${money.totalMonthlyExpensesActual.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Weekly Budget</p>
          <p className="text-xl font-semibold">${money.weeklyBudget.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Weekly Spending</p>
          <p className={`text-xl font-semibold ${overspending > 0 ? 'text-red-500' : 'text-green-500'}`}>${money.weeklySpending.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Safe to Spend</p>
          <p className="text-2xl font-bold text-primary">${money.safeToSpend.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Money Left</p>
          <p className="text-2xl font-bold">${money.moneyLeft.toFixed(2)}</p>
        </div>
      </div>
      <div className="flex justify-end">
        <p className={`text-sm font-medium ${statusColor}`}>Status: {status}</p>
      </div>
      <div className="h-56">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
            <XAxis dataKey="name" tick={{ fontSize: 10 }} interval={0} angle={-30} textAnchor="end" height={60} />
            <Tooltip formatter={(value: number) => `$${value.toFixed(2)}`} />
            <Legend wrapperStyle={{ fontSize: '12px' }} />
            <Bar dataKey="Budget" fill="#8884d8" radius={[4, 4, 0, 0]} />
            <Bar dataKey="Actual" fill="#82ca9d" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}