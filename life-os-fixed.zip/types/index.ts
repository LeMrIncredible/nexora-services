export interface Income {
  name: string;
  budget: number;
  actual: number;
}

export interface Expense {
  category: string;
  budget: number;
  actual: number;
}

export interface MoneyData {
  incomes: Income[];
  totalMonthlyIncomeBudget: number;
  totalMonthlyIncome: number;
  totalMonthlyExpensesBudget: number;
  totalMonthlyExpensesActual: number;
  weeklyBudget: number;
  weeklySpending: number;
  safeToSpend: number;
  moneyLeft: number;
  expenses: Expense[];
}

export interface BuildMilestone {
  item: string;
  chosenCost?: number | null;
  extraLogged?: number | null;
  currentTotal?: number | null;
  notes?: string;
}

export interface HousePlanData {
  stage: string;
  progress: number; // 0–1
  target: number; // total needed amount
  current: number; // current savings
  milestones: BuildMilestone[];
  nextSteps: string;
  blockers: string;
  timeline: {
    name: string;
    targetDate: string; // ISO date
    status: 'pending' | 'in-progress' | 'completed';
  }[];
}

export type TaskPriority = 'high' | 'medium' | 'low';
export type TaskStatus = 'todo' | 'in-progress' | 'done';

export interface Task {
  id: string;
  title: string;
  category: string;
  dueDate?: string;
  priority: TaskPriority;
  status: TaskStatus;
}

export type OpportunityStatus = 'todo' | 'in-progress' | 'done';

export interface Opportunity {
  id: string;
  title: string;
  type: string;
  estimatedValue: number;
  effort: number; // 1–10
  urgency: number; // 1–10
  status: OpportunityStatus;
  notes?: string;
}

export interface TradingIdea {
  id: string;
  symbol: string;
  entry: number;
  target: number;
  stop: number;
  conviction: number; // 0–1
  notes?: string;
}

// --- NEW TYPES FOR BRAIN LAYER ---

// Represents connection and credential information for external services.
// Each integration has an enabled flag, a connection status, and optional
// key or token fields. Additional properties can be added as needed for
// future integrations (e.g. OAuth tokens). Status is used to indicate
// whether the integration is connected, not connected, or in an error
// state.
export interface IntegrationCredential {
  /** Whether the user has toggled this integration on. */
  enabled: boolean;
  /**
   * Current connection status. 'connected' indicates that valid credentials
   * and/or tokens are available. 'not_connected' means the service has not
   * been authenticated yet. 'needs_setup' means that required environment
   * variables are missing. 'error' indicates a runtime or auth error.
   */
  status: 'not_connected' | 'connected' | 'needs_setup' | 'error';
  /** Optional error message for debugging or display. */
  error?: string;

  /**
   * API key or secret for this integration. Keys are stored locally and
   * passed to the server when fetching live data. They are optional
   * because some integrations (like Google OAuth) may not require a
   * static key. Secrets are never exposed outside of the application.
   */
  key?: string;

  /**
   * OAuth tokens returned from a provider such as Google. When present, the
   * application can use these tokens to access authenticated APIs (e.g.
   * Calendar and Sheets). Tokens are stored locally and sent to the server
   * only when making API calls. They may include fields like access_token,
   * refresh_token and expiry_date.
   */
  tokens?: any;

  /**
   * Identifier for a selected resource, such as the Google Sheet ID used
   * for the budget. When connecting to Google Sheets, this field stores
   * the user-selected sheet so the server knows which spreadsheet to query.
   */
  sheetId?: string;
}

// Container object for all integrations. Each property is optional and
// corresponds to a supported service.
export interface ConnectionsData {
  openai?: IntegrationCredential;
  gmail?: IntegrationCredential;
  calendar?: IntegrationCredential;
  market?: IntegrationCredential;
  verse?: IntegrationCredential;
  weather?: IntegrationCredential;

  /**
   * Google Sheets integration for budget data. This represents the
   * connection to a specific Google Sheets document. The sheetId
   * identifies which spreadsheet to read from. Status indicates if
   * the sheet is connected and mapped.
   */
  sheet?: IntegrationCredential;
}

// Represents a calendar event pulled from an external calendar service.
export interface CalendarEvent {
  id: string;
  title: string;
  start: string; // ISO date string
  end: string; // ISO date string
  location?: string;
  description?: string;
}

// Represents a brief summary of an email. The content is intentionally
// lightweight because the goal is to surface actionable insights rather
// than full email messages.
export interface EmailSummary {
  id: string;
  subject: string;
  snippet: string;
  receivedAt: string; // ISO date string
  from?: string;
}

// Represents a piece of market data for a given symbol. Values such as
// price and change may be updated frequently by a live data hook.
export interface MarketQuote {
  symbol: string;
  price: number;
  change: number;
  updatedAt: string; // ISO date string
}

// NEW TYPES FOR AUTOMATION LAYER

/**
 * Represents a single notification generated by the automation engine. Each
 * notification has an id, a type (e.g. 'financial', 'task', 'opportunity',
 * 'calendar', 'risk'), a human‑readable message, a timestamp and a flag
 * indicating whether the user has read it. Additional metadata could be
 * added later (e.g. links back to relevant pages or entities).
 */
export interface Notification {
  id: string;
  type: string;
  message: string;
  createdAt: string; // ISO date string
  read: boolean;
}

/**
 * A daily brief summarises the most important insights for the day. It
 * contains a concise focus message, a financial summary, a list of top
 * tasks, the best opportunity, any risks to watch out for and key
 * calendar events. The assistant and home page can reference this
 * structured summary to provide proactive guidance.
 */
export interface DailyBrief {
  id: string;
  createdAt: string;
  focus: string;
  financialSummary: string;
  topTasks: { title: string; dueDate?: string }[];
  bestOpportunity?: { title: string; value: number };
  risk?: string;
  events: { title: string; time: string }[];
}

/**
 * User‑configurable settings controlling the automation engine. The user can
 * enable or disable daily and periodic refreshes, choose the frequency of
 * updates and toggle notifications. Additional settings can be added as
 * automation features evolve.
 */
export interface AutomationSettings {
  dailyEnabled: boolean;
  periodicEnabled: boolean;
  // Frequency in minutes for periodic updates (e.g. 60 for hourly)
  periodicInterval: number;
  notificationsEnabled: boolean;
}

// Represents a single message exchanged in the chat assistant. The role
// can be 'user' or 'assistant'. Timestamp is stored as ISO string for
// ordering and display.
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

// Represents a recommendation generated by the recommendation engine. The
// type field can be used to categorise recommendations (e.g. 'focus',
// 'financial', 'house', etc.).
export interface Recommendation {
  id: string;
  type: string;
  content: string;
  createdAt: string; // ISO date string
}