"use client";

import { useState } from 'react';
import { useData } from '../context';
import type { MoneyData, Income, Expense } from '../../types';
import Card from '../../components/Card';
import ProgressBar from '../../components/ProgressBar';

export default function MoneyPage() {
  const { money, setMoney, connections, lastUpdated, setLastUpdated } = useData();
  // Local form state for adding a new expense
  const [newExpense, setNewExpense] = useState({ category: '', budget: 0, actual: 0 });

  // Refresh money data from a connected Google Sheet. Uses the stored
  // tokens, sheetId and mapping on the sheet integration to pull
  // latest values and update the Money state. If the sheet is not
  // connected, this does nothing.
  async function refreshFromSheet() {
    const sheet = connections.sheet;
    if (!sheet || sheet.status !== 'connected' || !sheet.tokens || !sheet.sheetId || !(sheet as any).mapping) {
      return;
    }
    try {
      const res = await fetch('/api/google/sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tokens: sheet.tokens, sheetId: sheet.sheetId }),
      });
      const data = await res.json();
      if (Array.isArray(data.values)) {
        const mapping = (sheet as any).mapping as any[];
        const parsed = parseMoneyFromSheet(data.values, mapping);
        if (parsed) {
          setMoney(parsed);
          setLastUpdated({ ...lastUpdated, sheet: new Date().toISOString() });
        }
      }
    } catch (err) {
      console.error('Failed to refresh from sheet', err);
    }
  }

  // Utility to parse sheet values into MoneyData. Duplicates logic from
  // the connections page so the Money page can refresh independently.
  function parseMoneyFromSheet(values: string[][], mapping: any[]): MoneyData | undefined {
    if (!values || values.length < 2) return undefined;
    const rows = values.slice(1);
    const idxCategory = mapping.findIndex((m) => m === 'Category');
    const idxType = mapping.findIndex((m) => m === 'Type');
    const idxBudget = mapping.findIndex((m) => m === 'Budget');
    const idxActual = mapping.findIndex((m) => m === 'Actual');
    if (idxCategory === -1 || idxBudget === -1) return undefined;
    const incomes: Income[] = [];
    const expenses: Expense[] = [];
    for (const row of rows) {
      const category = row[idxCategory] || '';
      if (!category) continue;
      const typeVal = idxType >= 0 ? (row[idxType] || '').toLowerCase() : '';
      const budgetVal = idxBudget >= 0 ? parseFloat(row[idxBudget] || '0') : 0;
      const actualVal = idxActual >= 0 ? parseFloat(row[idxActual] || row[idxBudget] || '0') : budgetVal;
      const isIncome = typeVal.includes('income') || typeVal.includes('salary') || typeVal.includes('revenue');
      if (isIncome) {
        incomes.push({ name: category, budget: budgetVal, actual: actualVal });
      } else {
        expenses.push({ category, budget: budgetVal, actual: actualVal });
      }
    }
    if (incomes.length === 0 && expenses.length === 0) return undefined;
    const totalMonthlyIncomeBudget = incomes.reduce((sum, i) => sum + i.budget, 0);
    const totalMonthlyIncome = incomes.reduce((sum, i) => sum + i.actual, 0);
    const totalMonthlyExpensesBudget = expenses.reduce((sum, e) => sum + e.budget, 0);
    const totalMonthlyExpensesActual = expenses.reduce((sum, e) => sum + e.actual, 0);
    const weeklyBudget = totalMonthlyExpensesBudget / 4;
    const weeklySpending = totalMonthlyExpensesActual / 4;
    const safeToSpend = weeklyBudget - weeklySpending;
    const moneyLeft = totalMonthlyIncome - totalMonthlyExpensesActual;
    return {
      incomes,
      totalMonthlyIncomeBudget,
      totalMonthlyIncome,
      totalMonthlyExpensesBudget,
      totalMonthlyExpensesActual,
      weeklyBudget,
      weeklySpending,
      safeToSpend,
      moneyLeft,
      expenses,
    };
  }

  const addExpense = () => {
    if (!newExpense.category) return;
    setMoney({
      ...money,
      expenses: [...money.expenses, { ...newExpense }],
    });
    setNewExpense({ category: '', budget: 0, actual: 0 });
  };

  const removeExpense = (index: number) => {
    const copy = money.expenses.slice();
    copy.splice(index, 1);
    setMoney({ ...money, expenses: copy });
  };

  // Calculate emergency fund goal: three months of budgeted expenses
  const emergencyTarget = money.totalMonthlyExpensesBudget * 3;
  const emergencySaved = 2000; // Placeholder; in a real app this would be tracked
  const emergencyProgress = emergencySaved / emergencyTarget;

  // House savings: reuse house progress from houseSeed but show as savings goal
  const houseTarget = 100000; // example house savings goal separate from build
  const houseSaved = 15000; // placeholder
  const houseProgress = houseSaved / houseTarget;

  // Determine spending status: on track or overspending this week
  const overspending = money.weeklySpending - money.weeklyBudget;
  const statusLabel = overspending > 0 ? 'Warning: You are overspending this week.' : 'You are on track with your weekly budget.';
  const statusColor = overspending > 0 ? 'text-red-500' : 'text-green-500';

  // Compute upcoming bills: assume monthly bills are due on the first of next month
  const now = new Date();
  const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const upcoming = money.expenses
    .filter((e) => (e.budget || e.actual) > 0)
    .map((e) => ({ ...e, dueDate: nextMonth }))
    .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime())
    .slice(0, 5);

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Money</h1>
      {/* Status indicator */}
      <div
        className={
          // Use tinted backgrounds instead of borders for status. This draws
          // attention without relying solely on thin border lines. Color
          // intensities are tuned for dark and light modes.
          `rounded-lg p-4 shadow-card ${
            overspending > 0
              ? 'bg-red-50 dark:bg-red-900/30'
              : 'bg-green-50 dark:bg-green-900/30'
          }`
        }
      >
        <p className={`font-semibold ${statusColor}`}>{statusLabel}</p>
      </div>
      <Card title="Overview" className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Cash on hand</p>
            <p className="text-2xl font-bold">${money.moneyLeft.toFixed(2)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Monthly Income</p>
            <p className="text-xl font-semibold">${money.totalMonthlyIncome.toFixed(2)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Monthly Expenses</p>
            <p className="text-xl font-semibold">${money.totalMonthlyExpensesActual.toFixed(2)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Safe‑to‑Spend (week)</p>
            <p className="text-2xl font-bold text-primary">${money.safeToSpend.toFixed(2)}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Weekly Budget</p>
            <p className="text-lg font-semibold">${money.weeklyBudget.toFixed(2)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Weekly Spending</p>
            <p className={`text-lg font-semibold ${overspending > 0 ? 'text-red-500' : 'text-green-500'}`}>${money.weeklySpending.toFixed(2)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Monthly Budget</p>
            <p className="text-lg font-semibold">${money.totalMonthlyExpensesBudget.toFixed(2)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Monthly Spending</p>
            <p className={`text-lg font-semibold ${money.totalMonthlyExpensesActual > money.totalMonthlyExpensesBudget ? 'text-red-500' : 'text-green-500'}`}>${money.totalMonthlyExpensesActual.toFixed(2)}</p>
          </div>
        </div>
      </Card>

      {/* Budget source status */}
      <Card title="Budget Source" className="space-y-2">
        {connections.sheet?.enabled && connections.sheet?.status === 'connected' ? (
          <div className="flex flex-col gap-2 text-sm">
            <p>Connected to Google Sheets.</p>
            <p className="text-gray-500">
              Last synced {lastUpdated.sheet ? new Date(lastUpdated.sheet).toLocaleString() : 'never'}.
            </p>
            <button
              onClick={refreshFromSheet}
              className="self-start px-3 py-1 bg-primary text-white text-xs rounded-md hover:bg-primary-dark"
            >
              Refresh Now
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-2 text-sm">
            <p>Using local budget data.</p>
            <p className="text-gray-500">
              Connect a Google Sheet from the Connections page to sync your budget.
            </p>
          </div>
        )}
      </Card>

      <Card title="Expenses" className="space-y-4">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200 dark:border-gray-700">
              <th className="text-left py-2">Category</th>
              <th className="text-right py-2">Budget</th>
              <th className="text-right py-2">Actual</th>
              <th className="py-2"></th>
            </tr>
          </thead>
          <tbody>
            {money.expenses.map((exp, idx) => (
              <tr key={idx} className="border-b border-gray-100 dark:border-gray-800">
                <td className="py-1">{exp.category}</td>
                <td className="py-1 text-right">${exp.budget.toFixed(2)}</td>
                <td className="py-1 text-right">${exp.actual.toFixed(2)}</td>
                <td className="py-1 text-right">
                  <button
                    className="text-xs text-red-500 hover:underline"
                    onClick={() => removeExpense(idx)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="flex gap-2 items-center mt-2">
          <input
            type="text"
            placeholder="Category"
            value={newExpense.category}
            onChange={(e) => setNewExpense({ ...newExpense, category: e.target.value })}
            className="flex-1 bg-transparent border-b border-gray-400 dark:border-gray-600 focus:outline-none focus:border-primary"
          />
          <input
            type="number"
            placeholder="Budget"
            value={newExpense.budget}
            onChange={(e) => setNewExpense({ ...newExpense, budget: parseFloat(e.target.value) || 0 })}
            className="w-20 bg-transparent border-b border-gray-400 dark:border-gray-600 text-right focus:outline-none focus:border-primary"
          />
          <input
            type="number"
            placeholder="Actual"
            value={newExpense.actual}
            onChange={(e) => setNewExpense({ ...newExpense, actual: parseFloat(e.target.value) || 0 })}
            className="w-20 bg-transparent border-b border-gray-400 dark:border-gray-600 text-right focus:outline-none focus:border-primary"
          />
          <button
            className="px-3 py-1 bg-primary text-white text-sm rounded-md hover:bg-primary-dark"
            onClick={addExpense}
          >
            Add
          </button>
        </div>
      </Card>

      {/* Upcoming bills section */}
      <Card title="Upcoming Bills" className="space-y-3">
        {upcoming.length > 0 ? (
          <ul className="divide-y divide-gray-200 dark:divide-gray-700 text-sm">
            {upcoming.map((bill, idx) => (
              <li key={idx} className="flex justify-between py-2">
                <span>{bill.category}</span>
                <span>{bill.dueDate.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} — ${bill.actual.toFixed(2)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-gray-500">No upcoming bills.</p>
        )}
      </Card>

      <Card title="Savings Goals" className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <p className="font-medium text-sm">Emergency Fund</p>
            <ProgressBar value={emergencyProgress} label={`${(emergencyProgress * 100).toFixed(1)}%`} />
            <p className="text-xs text-gray-500">${emergencySaved.toFixed(2)} / ${emergencyTarget.toFixed(2)} saved</p>
          </div>
          <div className="space-y-2">
            <p className="font-medium text-sm">House / Land Savings</p>
            <ProgressBar value={houseProgress} label={`${(houseProgress * 100).toFixed(1)}%`} />
            <p className="text-xs text-gray-500">${houseSaved.toFixed(2)} / ${houseTarget.toFixed(2)} saved</p>
          </div>
        </div>
      </Card>
    </div>
  );
}