"use client";

import { useData } from './context';
import Card from '../components/Card';
import MoneySummary from '../components/MoneySummary';
import ProgressBar from '../components/ProgressBar';
import { useMemo, useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarAlt, faEnvelope, faChartLine } from '@fortawesome/free-solid-svg-icons';
import { useRouter } from 'next/navigation';
import { useVerse } from '../hooks/useVerse';
import { useWeather } from '../hooks/useWeather';
import { useCalendar } from '../hooks/useCalendar';
import { useEmails } from '../hooks/useEmails';
import { useMarket } from '../hooks/useMarket';
import { useRecommendations } from '../hooks/useRecommendations';
import { faBell } from '@fortawesome/free-solid-svg-icons';

// Services for manual daily brief generation when the user taps refresh
import { generateDailyBrief } from '../utils/services/dailyBrief';
import { generateNotifications } from '../utils/services/notifications';
import { generateRecommendations as generateRecs } from '../utils/recommendations';

function getGreeting(): string {
  const now = new Date();
  const hours = now.getHours();
  if (hours < 12) return 'Good morning';
  if (hours < 18) return 'Good afternoon';
  return 'Good evening';
}

export default function Home() {
  const {
    money,
    house,
    tasks,
    opportunities,
    trading,
    calendarEvents,
    emails,
    market,
    recommendations,
    connections,
    notifications,
    setNotifications,
    dailyBrief,
    setDailyBrief,
    setRecommendations,
    lastUpdated,
  } = useData();

  const router = useRouter();

  // Load live integrations. These hooks will update global state when
  // integrations are enabled. They return data for verse and weather while
  // others update the context automatically.
  const verse = useVerse();
  const weather = useWeather();
  useCalendar();
  useEmails();
  useMarket();
  useRecommendations();

  // Determine if verse should be displayed; stored in localStorage under 'showVerse'.
  const [showVerse, setShowVerse] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    const val = localStorage.getItem('showVerse');
    return val !== 'false';
  });

  // Redirect to onboarding if the user has not completed the initial setup.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const onboarded = localStorage.getItem('onboarded');
    if (!onboarded || onboarded !== 'true') {
      router.push('/onboarding');
    }
  }, [router]);

  // Determine top 3 priorities: sort tasks by priority and due date
  const priorities = useMemo(() => {
    const priorityOrder: Record<string, number> = { high: 1, medium: 2, low: 3 };
    return [...tasks]
      .filter((t) => t.status !== 'done')
      .sort((a, b) => {
        const pa = priorityOrder[a.priority];
        const pb = priorityOrder[b.priority];
        if (pa !== pb) return pa - pb;
        if (a.dueDate && b.dueDate) return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        return 0;
      })
      .slice(0, 3);
  }, [tasks]);

  // Count unread notifications to display a badge
  const unreadCount = notifications.filter((n) => !n.read).length;

  // Money insights
  const overspending = money.weeklySpending - money.weeklyBudget;
  const moneyMessage = overspending > 0 ? `You are overspending by $${overspending.toFixed(2)} this week.` : 'You are on track this week!';
  const safeMessage = `You can safely spend $${money.safeToSpend.toFixed(2)}.`;

  // Determine classes for the daily focus card based on spending status. Use
  // tinted backgrounds and coloured text to subtly highlight the current
  // financial state without overwhelming the user. These classes apply
  // consistently across light and dark modes.
  const focusBg = overspending > 0 ? 'bg-red-50 dark:bg-red-900/30' : 'bg-green-50 dark:bg-green-900/30';
  const focusText = overspending > 0 ? 'text-red-700 dark:text-red-300' : 'text-green-700 dark:text-green-300';

  // Opportunities summary
  const bestOpportunity = useMemo(() => {
    return opportunities
      .filter((o) => o.status !== 'done')
      .sort((a, b) => {
        // simple score: value * urgency / effort
        const scoreA = (a.estimatedValue * a.urgency) / a.effort;
        const scoreB = (b.estimatedValue * b.urgency) / b.effort;
        return scoreB - scoreA;
      })[0];
  }, [opportunities]);

  // Collect today's events and top email summaries. We'll compute counts
  // but also take into account whether the corresponding integration is
  // connected. If an integration is disabled or disconnected, we display
  // a not connected message instead of empty data.
  const todayStr = new Date().toDateString();
  const todaysEvents = calendarEvents.filter(
    (ev) => new Date(ev.start).toDateString() === todayStr,
  ).slice(0, 2);
  const emailCount = emails.length;
  const marketCount = market.length;

  return (
    <div className="space-y-8">
      {/* Greeting, verse and quick actions */}
      <Card className="space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h1 className="text-4xl font-bold">
              {getGreeting()}, it’s{' '}
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
            </h1>
            {showVerse && verse && (
              <p className="italic text-primary text-sm md:text-base">
                “{verse.text}” <span className="not-italic text-gray-500">— {verse.reference}</span>
              </p>
            )}
            {weather && (
              <p className="text-xs text-gray-500">
                {weather.location}: {weather.temp}°F, {weather.condition}
              </p>
            )}
          </div>
          {/* Actions: Ask Life OS and notifications */}
          <div className="flex items-center gap-4 self-start md:self-auto">
            <a
              href="/chat"
              className="px-4 py-2 bg-primary text-white text-sm rounded-md hover:bg-primary-dark"
            >
              Ask Life OS
            </a>
            <div
              className="relative cursor-pointer"
              onClick={() => {
                // Mark all notifications as read when clicking the bell
                setNotifications(notifications.map((n) => ({ ...n, read: true })));
              }}
            >
              <FontAwesomeIcon icon={faBell} className="w-5 h-5 text-primary" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] rounded-full px-1">
                  {unreadCount}
                </span>
              )}
            </div>
          </div>
        </div>
      </Card>

      {/* Quick glance cards for schedule, emails and market */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Schedule card */}
        <Card title="Today’s Schedule" className="flex flex-col justify-between">
          <div className="flex items-start gap-3">
            <FontAwesomeIcon icon={faCalendarAlt} className="text-primary mt-1" />
            <div className="flex-1 space-y-1">
              {connections.calendar?.enabled && connections.calendar?.status === 'connected' ? (
                todaysEvents.length > 0 ? (
                  <>
                    <p className="text-3xl font-bold">{todaysEvents.length}</p>
                    <p className="text-sm text-gray-500">event{todaysEvents.length === 1 ? '' : 's'} today</p>
                    <ul className="space-y-1">
                      {todaysEvents.map((ev) => (
                        <li key={ev.id} className="text-xs">
                          <span className="font-medium">{ev.title}</span>{' '}@{' '}
                          {new Date(ev.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </li>
                      ))}
                    </ul>
                  </>
                ) : (
                  <>
                    <p className="text-3xl font-bold">0</p>
                    <p className="text-sm text-gray-500">No events today</p>
                  </>
                )
              ) : (
                <>
                  <p className="text-3xl font-bold">—</p>
                  <p className="text-sm text-gray-500">Connect Google Calendar to see events</p>
                </>
              )}
            </div>
          </div>
        </Card>
        {/* Emails card */}
        <Card title="Important Emails" className="flex flex-col justify-between">
          <div className="flex items-start gap-3">
            <FontAwesomeIcon icon={faEnvelope} className="text-primary mt-1" />
            <div className="flex-1 space-y-1">
              {connections.gmail?.enabled && connections.gmail?.status === 'connected' ? (
                emailCount > 0 ? (
                  <>
                    <p className="text-3xl font-bold">{emailCount}</p>
                    <p className="text-sm text-gray-500">important email{emailCount === 1 ? '' : 's'}</p>
                  </>
                ) : (
                  <>
                    <p className="text-3xl font-bold">0</p>
                    <p className="text-sm text-gray-500">No important emails</p>
                  </>
                )
              ) : (
                <>
                  <p className="text-3xl font-bold">—</p>
                  <p className="text-sm text-gray-500">Email not connected</p>
                </>
              )}
            </div>
          </div>
        </Card>
        {/* Market card */}
        <Card title="Market Watch" className="flex flex-col justify-between">
          <div className="flex items-start gap-3">
            <FontAwesomeIcon icon={faChartLine} className="text-primary mt-1" />
            <div className="flex-1 space-y-1">
              {connections.market?.enabled && connections.market?.status === 'connected' ? (
                marketCount > 0 ? (
                  <>
                    <p className="text-3xl font-bold">{marketCount}</p>
                    <p className="text-sm text-gray-500">symbol{marketCount === 1 ? '' : 's'} tracked</p>
                  </>
                ) : (
                  <>
                    <p className="text-3xl font-bold">0</p>
                    <p className="text-sm text-gray-500">No market data</p>
                  </>
                )
              ) : (
                <>
                  <p className="text-3xl font-bold">—</p>
                  <p className="text-sm text-gray-500">Market not connected</p>
                </>
              )}
            </div>
          </div>
        </Card>
      </div>

      {/* Daily brief card summarising today’s situation */}
      <Card title="Daily Brief" className="space-y-3">
        {dailyBrief ? (
          <div className="space-y-2 text-sm">
            <p><span className="font-semibold">Focus:</span> {dailyBrief.focus}</p>
            <p><span className="font-semibold">Financial:</span> {dailyBrief.financialSummary}</p>
            {dailyBrief.topTasks.length > 0 && (
              <p><span className="font-semibold">Top tasks:</span> {dailyBrief.topTasks.map((t) => t.title).join(', ')}</p>
            )}
            {dailyBrief.bestOpportunity && (
              <p><span className="font-semibold">Best opportunity:</span> {dailyBrief.bestOpportunity.title} (≈${dailyBrief.bestOpportunity.value.toLocaleString()})</p>
            )}
            {dailyBrief.risk && (
              <p><span className="font-semibold">Risk:</span> {dailyBrief.risk}</p>
            )}
            {dailyBrief.events.length > 0 && (
              <p><span className="font-semibold">Events:</span> {dailyBrief.events.map((e) => `${e.title} @ ${e.time}`).join(', ')}</p>
            )}
            {/* Last updated timestamp */}
            {lastUpdated.dailyBrief && (
              <p className="text-xs text-gray-500">Updated {new Date(lastUpdated.dailyBrief).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
            )}
            {/* Manual refresh button */}
            <button
              className="mt-1 px-3 py-1 bg-gray-50 dark:bg-gray-700/50 text-xs rounded-md hover:bg-gray-100 dark:hover:bg-gray-600"
              onClick={() => {
                // Generate daily brief, notifications and recommendations manually
                const brief = generateDailyBrief(money, tasks, opportunities, house, calendarEvents);
                setDailyBrief(brief);
                // Optionally generate notifications
                const newNotifs = generateNotifications(money, tasks, opportunities, house, calendarEvents);
                setNotifications([...notifications, ...newNotifs]);
                const recs = generateRecs(money, house, tasks, opportunities, trading, calendarEvents);
                setRecommendations(recs);
              }}
            >
              Refresh Daily Brief
            </button>
          </div>
        ) : (
          <div className="space-y-2 text-sm">
            <p>Your daily brief is not available yet.</p>
            <p className="text-xs text-gray-500">Enable automation or click the button below to generate a brief now.</p>
            <button
              className="px-3 py-1 bg-gray-50 dark:bg-gray-700/50 text-xs rounded-md hover:bg-gray-100 dark:hover:bg-gray-600"
              onClick={() => {
                const brief = generateDailyBrief(money, tasks, opportunities, house, calendarEvents);
                setDailyBrief(brief);
                const newNotifs = generateNotifications(money, tasks, opportunities, house, calendarEvents);
                setNotifications([...notifications, ...newNotifs]);
                const recs = generateRecs(money, house, tasks, opportunities, trading, calendarEvents);
                setRecommendations(recs);
              }}
            >
              Generate Daily Brief
            </button>
          </div>
        )}
      </Card>

      {/* Daily focus, top tasks and recommendations summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card title="Daily Focus" className="space-y-3">
          <div className={`rounded-md p-3 ${focusBg} ${focusText}`}>
            <p className="text-base font-semibold">
              {overspending > 0 ? '⚠️ Overspending Alert' : '✅ You’re on track'}
            </p>
            <p className="text-sm mb-1">
              {overspending > 0 ? moneyMessage : safeMessage}
            </p>
            <p className="text-sm font-medium">
              Safe to spend: ${money.safeToSpend.toFixed(2)}
            </p>
          </div>
        </Card>
        <Card title="Top Tasks" className="space-y-3">
          {priorities.length > 0 ? (
            <ul className="space-y-2">
              {priorities.map((task) => (
                <li key={task.id} className="flex justify-between items-baseline">
                  <span className="font-medium">{task.title}</span>
                  {task.dueDate && (
                    <span className="text-xs text-gray-500">
                      {new Date(task.dueDate).toLocaleDateString()}
                    </span>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-500">You have no high‑priority tasks.</p>
          )}
        </Card>
        <Card title="Recommendations" className="space-y-3">
          {recommendations.length > 0 ? (
            <div className="space-y-2">
              {recommendations.slice(0,5).map((rec) => {
                // Determine badge colour based on recommendation type
                const badgeClass = (() => {
                  switch (rec.type) {
                    case 'financial':
                      return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300';
                    case 'focus':
                      return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300';
                    case 'opportunity':
                      return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
                    case 'house':
                      return 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300';
                    case 'calendar':
                      return 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300';
                    case 'trading':
                      return 'bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300';
                    case 'risk':
                      return 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300';
                    default:
                      return 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300';
                  }
                })();
                const label = rec.type.charAt(0).toUpperCase() + rec.type.slice(1);
                return (
                  <div key={rec.id} className="flex items-start gap-2">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${badgeClass}`}>{label}</span>
                    <p className="text-sm leading-snug flex-1">{rec.content}</p>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-gray-500">No recommendations available.</p>
          )}
        </Card>
      </div>

      {/* Money snapshot */}
      <MoneySummary />

      {/* House progress and opportunities/trading */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="House Progress" className="space-y-3">
          <p className="text-sm">
            Current stage: <span className="font-medium">{house.stage}</span>
          </p>
          <ProgressBar value={house.progress} label={`${(house.progress * 100).toFixed(1)}% complete`} />
          <p className="text-sm">
            ${house.current.toLocaleString(undefined, { maximumFractionDigits: 2 })} /
            ${house.target.toLocaleString(undefined, { maximumFractionDigits: 2 })} saved
          </p>
        </Card>
        <div className="space-y-6">
          <Card title="Opportunities" className="space-y-3">
            {bestOpportunity ? (
              <div>
                <p className="font-medium">Best opportunity today:</p>
                <p className="text-sm">
                  {bestOpportunity.title} — potential ${bestOpportunity.estimatedValue.toLocaleString()}
                </p>
              </div>
            ) : (
              <p className="text-sm text-gray-500">No active opportunities right now.</p>
            )}
          </Card>
          <Card title="Trading" className="space-y-3">
            <p className="text-sm">You have {trading.length} idea{trading.length === 1 ? '' : 's'} on your watchlist.</p>
          </Card>
        </div>
      </div>

      {/* Notifications section */}
      <Card title="Notifications" className="space-y-3">
        {notifications.length > 0 ? (
          <div className="space-y-2">
            {notifications
              .slice()
              .reverse()
              .slice(0, 5)
              .map((n) => (
                <div key={n.id} className="flex justify-between items-start gap-2 border-b border-gray-200 dark:border-gray-700 pb-2 last:border-none">
                  <div className="flex-1">
                    <p className={`text-sm ${n.read ? 'text-gray-500' : 'text-gray-900 dark:text-gray-100'}`}>{n.message}</p>
                    <p className="text-[10px] text-gray-400">{new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                  {!n.read && <span className="text-xs font-medium text-primary">New</span>}
                </div>
              ))}
          </div>
        ) : (
          <p className="text-sm text-gray-500">No notifications at the moment.</p>
        )}
        {notifications.length > 0 && (
          <div className="flex justify-end">
            <button
              className="text-xs text-primary underline hover:text-primary-dark"
              onClick={() => setNotifications(notifications.map((n) => ({ ...n, read: true })))}
            >
              Mark all as read
            </button>
          </div>
        )}
      </Card>
    </div>
  );
}