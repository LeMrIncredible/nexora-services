"use client";

// import useState removed because it's not used in this component
import { useData } from '../context';
import { useState, useEffect } from 'react';
import Card from '../../components/Card';
import type { IntegrationCredential, ConnectionsData, MoneyData, Income, Expense } from '../../types';
import { extractSheetId } from '../../utils/services/google';

/**
 * The Connections page provides a single location for managing all external
 * integrations used by Life OS. Users can enable or disable services,
 * provide API keys where required, and view connection status. For now,
 * authentication flows are stubbed out; toggling an integration simply
 * flips its status between connected and not connected.
 */
export default function ConnectionsPage() {
  const { connections, setConnections, money, setMoney, lastUpdated, setLastUpdated } = useData();

  // Track visibility of secret keys. When true, the key is shown; otherwise it is masked.
  const [showOpenaiKey, setShowOpenaiKey] = useState(false);
  const [showMarketKey, setShowMarketKey] = useState(false);
  const [showVerseKey, setShowVerseKey] = useState(false);
  const [showWeatherKey, setShowWeatherKey] = useState(false);

  // When the sheet is connected and mapped, fetch the latest values and
  // update the Money state. This runs on mount or whenever the sheet
  // connection status changes to 'connected'. It relies on tokens and
  // sheetId stored on the connections object.
  useEffect(() => {
    async function resyncFromSheet() {
      if (
        connections.sheet?.enabled &&
        connections.sheet?.status === 'connected' &&
        connections.sheet.sheetId &&
        connections.sheet.tokens &&
        (connections.sheet as any).mapping
      ) {
        try {
          const res = await fetch('/api/google/sheets', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tokens: connections.sheet.tokens, sheetId: connections.sheet.sheetId }),
          });
          const data = await res.json();
          if (Array.isArray(data.values)) {
            const mapping = (connections.sheet as any).mapping as ColumnOption[];
            const moneyData = parseMoneyFromSheet(data.values, mapping);
            if (moneyData) {
              setMoney(moneyData);
              setLastUpdated({ ...lastUpdated, sheet: new Date().toISOString() });
            }
          }
        } catch (err) {
          console.error('Failed to resync sheet', err);
        }
      }
    }
    resyncFromSheet();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connections.sheet?.status]);

  // Google Sheet connection state. When connecting a budget sheet we
  // allow the user to paste a link or ID, then load sample data and
  // select which columns map to our Money model. mappingStep controls
  // whether the column mapping UI is shown.
  const COLUMN_OPTIONS = ['Ignore', 'Category', 'Type', 'Budget', 'Actual'] as const;
  type ColumnOption = (typeof COLUMN_OPTIONS)[number];
  const [sheetUrl, setSheetUrl] = useState('');
  const [sheetLoading, setSheetLoading] = useState(false);
  const [sheetError, setSheetError] = useState('');
  const [sheetValues, setSheetValues] = useState<string[][] | null>(null);
  const [columnMappings, setColumnMappings] = useState<ColumnOption[]>([]);
  const [mappingStep, setMappingStep] = useState(false);

  // Helper to test a given integration using its current key. Upon success
  // updates the connection status to 'connected'; on failure sets
  // 'error'. This function sends a lightweight request to the server API.
  const testIntegration = async (service: keyof ConnectionsData) => {
    try {
      switch (service) {
        case 'openai': {
          const key = connections.openai?.key || '';
          if (!key) return;
          const res = await fetch('/api/assistant', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: 'ping', context: {}, apiKey: key }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.reply) {
              updateService('openai', { status: 'connected', error: undefined });
              return;
            }
          }
          updateService('openai', { status: 'error', error: 'Invalid API key or connection error' });
          break;
        }
        case 'market': {
          const key = connections.market?.key || '';
          if (!key) return;
          const res = await fetch(`/api/market?symbols=AAPL&key=${encodeURIComponent(key)}`);
          if (res.ok) {
            const data = await res.json();
            if (data.quotes && data.quotes.length > 0) {
              updateService('market', { status: 'connected', error: undefined });
              return;
            }
          }
          updateService('market', { status: 'error', error: 'Invalid API key or connection error' });
          break;
        }
        case 'weather': {
          const key = connections.weather?.key || '';
          if (!key) return;
          const res = await fetch(`/api/weather?key=${encodeURIComponent(key)}`);
          if (res.ok) {
            const data = await res.json();
            if (data.weather) {
              updateService('weather', { status: 'connected', error: undefined });
              return;
            }
          }
          updateService('weather', { status: 'error', error: 'Invalid API key or connection error' });
          break;
        }
        case 'verse': {
          const key = connections.verse?.key || '';
          // If no key, call default verse endpoint
          const res = await fetch(`/api/verse${key ? `?source=${encodeURIComponent(key)}` : ''}`);
          if (res.ok) {
            const data = await res.json();
            if (data.verse) {
              updateService('verse', { status: 'connected', error: undefined });
              return;
            }
          }
          updateService('verse', { status: 'error', error: 'Invalid verse source or connection error' });
          break;
        }
        default:
          break;
      }
    } catch (err) {
      console.error('Test integration error', err);
      updateService(service, { status: 'error', error: 'Connection test failed' });
    }
  };

  // Helper to update a specific integration. This merges the provided
  // changes into the existing credential object and updates the global
  // connections state.
  const updateService = (
    service: keyof ConnectionsData,
    updates: Partial<IntegrationCredential>,
  ) => {
    const current = connections[service] || { enabled: false, status: 'not_connected' } as IntegrationCredential;
    const next = { ...current, ...updates };
    setConnections({ ...connections, [service]: next });
  };

  /**
   * Initiate the Google OAuth flow. Requests an auth URL from the server
   * and redirects the browser to that URL. Once the user completes
   * authentication they will be returned to /google-callback where
   * tokens will be processed and stored. We set the calendar status
   * to 'needs_setup' here to indicate progress.
   */
  const handleGoogleConnect = async () => {
    try {
      const res = await fetch('/api/google/auth');
      const data = await res.json();
      if (data.url) {
        updateService('calendar', { status: 'needs_setup' });
        window.location.href = data.url;
      }
    } catch (err) {
      console.error('Google auth error', err);
      updateService('calendar', { status: 'error', error: 'Unable to initiate Google auth' });
    }
  };

  /**
   * Disconnect the Google account by clearing tokens and resetting
   * statuses for calendar and sheet. Also clears the sheetId and
   * mapping so the user can connect a different sheet later.
   */
  const handleGoogleDisconnect = () => {
    const { calendar, sheet, ...rest } = connections;
    const resetCalendar: IntegrationCredential = {
      ...calendar,
      status: 'not_connected',
      tokens: undefined,
    };
    const resetSheet: IntegrationCredential = {
      ...sheet,
      status: 'not_connected',
      tokens: undefined,
      sheetId: undefined,
    };
    // Remove mapping from sheet if present
    if (resetSheet && (resetSheet as any).mapping) {
      delete (resetSheet as any).mapping;
    }
    setConnections({ ...connections, calendar: resetCalendar, sheet: resetSheet });
  };

  /**
   * Handle connecting to a Google Sheet. Extracts the sheet ID from
   * the provided URL or ID, fetches values using the stored OAuth
   * tokens and enters a mapping step when successful. Errors are
   * displayed to the user.
   */
  const handleSheetConnect = async () => {
    if (!sheetUrl) {
      setSheetError('Please enter a Google Sheet link or ID');
      return;
    }
    const sheetId = extractSheetId(sheetUrl);
    if (!sheetId) {
      setSheetError('Could not extract spreadsheet ID from the provided link');
      return;
    }
    if (!connections.calendar?.tokens) {
      setSheetError('Google account not connected');
      return;
    }
    setSheetLoading(true);
    setSheetError('');
    try {
      const res = await fetch('/api/google/sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tokens: connections.calendar.tokens, sheetId }),
      });
      const data = await res.json();
      if (res.ok && Array.isArray(data.values) && data.values.length > 0) {
        setSheetValues(data.values);
        // initialise mapping: default first column Category, second Budget, third Actual, others Ignore
        const defaultMapping: ColumnOption[] = data.values[0].map((_: any, idx: number) => {
          if (idx === 0) return 'Category';
          if (idx === 1) return 'Budget';
          if (idx === 2) return 'Actual';
          return 'Ignore';
        });
        // Attempt to guess a Type column if there is a column named Type or Income/Expense
        if (data.values[0].some((header: string) => /type/i.test(header))) {
          const typeIndex = data.values[0].findIndex((h: string) => /type/i.test(h));
          defaultMapping[typeIndex] = 'Type';
        }
        setColumnMappings(defaultMapping);
        setMappingStep(true);
        // Temporarily store sheetId on the sheet connection so we know which doc is selected
        const updatedSheet: IntegrationCredential = {
          ...(connections.sheet || { enabled: true, status: 'not_connected' }),
          sheetId,
        };
        setConnections({ ...connections, sheet: updatedSheet });
      } else {
        setSheetError('Failed to load sheet values');
      }
    } catch (err) {
      console.error('Sheet connect error', err);
      setSheetError('Unexpected error while loading the sheet');
    } finally {
      setSheetLoading(false);
    }
  };

  /**
   * Handle importing the mapped sheet into the Money data model. Parses
   * the sheet rows according to the selected column mappings, updates
   * the Money state, stores the mapping on the sheet connection and
   * marks the sheet as connected. If parsing fails, show an error.
   */
  const handleImportSheet = () => {
    if (!sheetValues) return;
    const moneyData = parseMoneyFromSheet(sheetValues, columnMappings);
    if (moneyData) {
      setMoney(moneyData);
      // Save mapping on the sheet integration for future re-sync
      const updatedSheet: IntegrationCredential = {
        ...(connections.sheet || { enabled: true, status: 'not_connected' }),
        status: 'connected',
        tokens: connections.calendar?.tokens,
        sheetId: connections.sheet?.sheetId,
      };
      (updatedSheet as any).mapping = columnMappings;
      setConnections({ ...connections, sheet: updatedSheet });
      setMappingStep(false);
      setSheetValues(null);
      setSheetUrl('');
      // Record last updated time
      setLastUpdated({ ...lastUpdated, sheet: new Date().toISOString() });
    } else {
      setSheetError('Failed to parse sheet. Please adjust your mapping or check the sheet format.');
    }
  };

  /**
   * Manual refresh of sheet data. Uses the stored mapping to parse the
   * latest sheet values and updates the Money state accordingly.
   */
  const handleSheetRefresh = async () => {
    if (!connections.sheet?.tokens || !connections.sheet?.sheetId || !(connections.sheet as any).mapping) return;
    try {
      const res = await fetch('/api/google/sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tokens: connections.sheet.tokens, sheetId: connections.sheet.sheetId }),
      });
      const data = await res.json();
      if (Array.isArray(data.values)) {
        const moneyData = parseMoneyFromSheet(data.values, (connections.sheet as any).mapping as ColumnOption[]);
        if (moneyData) {
          setMoney(moneyData);
          setLastUpdated({ ...lastUpdated, sheet: new Date().toISOString() });
        }
      }
    } catch (err) {
      console.error('Sheet refresh error', err);
    }
  };

  /**
   * Handle disconnecting the sheet. Clears the sheetId, mapping and
   * resets the status. Does not clear Money data; the user can switch back to local mode.
   */
  const handleSheetDisconnect = () => {
    const resetSheet: IntegrationCredential = {
      ...(connections.sheet || { enabled: true, status: 'not_connected' }),
      status: 'not_connected',
      sheetId: undefined,
      tokens: undefined,
    };
    if ((resetSheet as any).mapping) {
      delete (resetSheet as any).mapping;
    }
    setConnections({ ...connections, sheet: resetSheet });
  };

  // Utility to parse budget data from a Google Sheet. Takes the raw
  // values returned by the Sheets API and a mapping array which
  // indicates which column holds the category, type, budget and actual
  // values. It builds a MoneyData structure from the rows. If no
  // income or expense rows can be parsed it returns undefined.
  function parseMoneyFromSheet(values: string[][], mapping: ColumnOption[]): MoneyData | undefined {
    if (!values || values.length < 2) return undefined;
    const header = values[0];
    const rows = values.slice(1);
    const idxCategory = mapping.findIndex((m) => m === 'Category');
    const idxType = mapping.findIndex((m) => m === 'Type');
    const idxBudget = mapping.findIndex((m) => m === 'Budget');
    const idxActual = mapping.findIndex((m) => m === 'Actual');
    if (idxCategory === -1 || idxBudget === -1) return undefined;
    const incomes: Income[] = [];
    const expenses: Expense[] = [];
    for (const row of rows) {
      const category = row[idxCategory] || '';
      if (!category) continue;
      const typeVal = idxType >= 0 ? (row[idxType] || '').toLowerCase() : '';
      const budgetVal = idxBudget >= 0 ? parseFloat(row[idxBudget] || '0') : 0;
      const actualVal = idxActual >= 0 ? parseFloat(row[idxActual] || row[idxBudget] || '0') : budgetVal;
      // Determine if this row is an income or expense
      const isIncome = typeVal.includes('income') || typeVal.includes('salary') || typeVal.includes('revenue');
      if (isIncome) {
        incomes.push({ name: category, budget: budgetVal, actual: actualVal });
      } else {
        expenses.push({ category, budget: budgetVal, actual: actualVal });
      }
    }
    if (incomes.length === 0 && expenses.length === 0) return undefined;
    // Aggregate totals
    const totalMonthlyIncomeBudget = incomes.reduce((sum, i) => sum + i.budget, 0);
    const totalMonthlyIncome = incomes.reduce((sum, i) => sum + i.actual, 0);
    const totalMonthlyExpensesBudget = expenses.reduce((sum, e) => sum + e.budget, 0);
    const totalMonthlyExpensesActual = expenses.reduce((sum, e) => sum + e.actual, 0);
    const weeklyBudget = totalMonthlyExpensesBudget / 4;
    const weeklySpending = totalMonthlyExpensesActual / 4;
    const safeToSpend = weeklyBudget - weeklySpending;
    const moneyLeft = totalMonthlyIncome - totalMonthlyExpensesActual;
    return {
      incomes,
      totalMonthlyIncomeBudget,
      totalMonthlyIncome,
      totalMonthlyExpensesBudget,
      totalMonthlyExpensesActual,
      weeklyBudget,
      weeklySpending,
      safeToSpend,
      moneyLeft,
      expenses,
    };
  }

  // Determine badge classes for a given status. Returns a set of
  // classes that include padding, rounded edges and colour. These
  // classes can be applied directly to a span to show the current
  // connection status as a pill.
  const statusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300';
      case 'needs_setup':
        return 'px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
      case 'error':
        return 'px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300';
      default:
        return 'px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  // Convert internal status codes to human‑readable labels. This
  // helper capitalises the first letter and replaces underscores
  // with spaces. Unknown statuses fall back to the raw value.
  const formatStatus = (status?: string) => {
    if (!status) return 'Not connected';
    switch (status) {
      case 'connected':
        return 'Connected';
      case 'not_connected':
        return 'Not connected';
      case 'needs_setup':
        return 'Needs setup';
      case 'error':
        return 'Error';
      default:
        // Replace underscores with spaces and capitalise first letter
        return status.charAt(0).toUpperCase() + status.slice(1).replace(/_/g, ' ');
    }
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Connections</h1>
      <p className="text-sm text-gray-500">
        Manage the services that power Life OS. Enable or disable integrations, add API keys and see connection status.
      </p>
      <p className="text-xs text-gray-500 italic">
        Secrets entered here are stored locally in your browser and passed securely to the server only when needed.
      </p>
      {/* AI Assistant Integration */}
      <Card title="AI Assistant" className="space-y-4">
        <div className="flex flex-col gap-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex-1">
              <p className="font-medium">OpenAI</p>
              <p className="text-sm text-gray-500">Provides chat and smart recommendations.</p>
            </div>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={!!connections.openai?.enabled}
                  onChange={(e) => updateService('openai', { enabled: e.target.checked })}
                />
                <span className="text-sm">Enable</span>
              </label>
              <span
                className={statusColor(connections.openai?.status || 'not_connected')}
              >
                {formatStatus(connections.openai?.status)}
              </span>
            </div>
          </div>
          {/* API key input */}
          {connections.openai?.enabled && (
            <div className="flex flex-col md:flex-row items-center gap-3">
              <div className="flex-1">
                <label className="block text-xs font-medium mb-1">API Key</label>
                <div className="flex items-center gap-2">
                  <input
                    type={showOpenaiKey ? 'text' : 'password'}
                    value={connections.openai.key || ''}
                    onChange={(e) => updateService('openai', { key: e.target.value, status: 'not_connected', error: undefined })}
                    placeholder="Enter your OpenAI API key"
                    className="flex-1 bg-transparent border-b border-gray-300 dark:border-gray-600 py-1 text-sm focus:outline-none"
                  />
                  <button
                    onClick={() => setShowOpenaiKey((prev) => !prev)}
                    className="text-xs text-primary underline"
                  >
                    {showOpenaiKey ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => testIntegration('openai')}
                  className="px-3 py-1 bg-primary text-white text-xs rounded-md hover:bg-primary-dark"
                >
                  Test
                </button>
              </div>
            </div>
          )}
          {connections.openai?.error && (
            <p className="text-xs text-red-600">{connections.openai.error}</p>
          )}
        </div>
      </Card>

      {/* Email Integration */}
      {/* Gmail Integration (currently unavailable) */}
      <Card title="Email" className="space-y-4">
        <div className="flex flex-col gap-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex-1">
              <p className="font-medium">Gmail</p>
              <p className="text-sm text-gray-500">
                Integration coming soon. Email summaries will appear here once supported.
              </p>
            </div>
            <span className={statusColor('not_connected')}>Not available</span>
          </div>
        </div>
      </Card>

      {/* Calendar Integration */}
      <Card title="Calendar" className="space-y-4">
        <div className="flex flex-col gap-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex-1">
              <p className="font-medium">Google Calendar</p>
              <p className="text-sm text-gray-500">Display upcoming events on your dashboard and enable budget sheet import.</p>
            </div>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={!!connections.calendar?.enabled}
                  onChange={(e) => updateService('calendar', { enabled: e.target.checked })}
                />
                <span className="text-sm">Enable</span>
              </label>
              <span className={statusColor(connections.calendar?.status || 'not_connected')}>
                {formatStatus(connections.calendar?.status || 'not_connected')}
              </span>
            </div>
          </div>
          {connections.calendar?.enabled && (
            <div className="flex flex-col gap-2">
              {/* When not yet connected, show a connect button and instructions */}
              {connections.calendar.status !== 'connected' ? (
                <>
                  <button
                    onClick={handleGoogleConnect}
                    className="px-3 py-1 bg-primary text-white text-xs rounded-md hover:bg-primary-dark w-max"
                  >
                    Connect Google Account
                  </button>
                  <p className="text-xs text-gray-500">
                    Sign in with your Google account to sync your calendar and allow budget sheet import.
                  </p>
                  {connections.calendar.status === 'needs_setup' && (
                    <p className="text-xs text-gray-500">Waiting for Google authorization…</p>
                  )}
                  {connections.calendar.status === 'error' && (
                    <p className="text-xs text-red-600">{connections.calendar.error}</p>
                  )}
                </>
              ) : (
                <>
                  <p className="text-xs text-gray-500">
                    Connected to Google. Last synced{' '}
                    {lastUpdated.calendar ? new Date(lastUpdated.calendar).toLocaleString() : 'never'}.
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={handleGoogleDisconnect}
                      className="px-3 py-1 bg-red-500 text-white text-xs rounded-md hover:bg-red-600"
                    >
                      Disconnect
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </Card>

      {/* Budget Sheet Integration */}
      <Card title="Budget Sheet" className="space-y-4">
        <div className="flex flex-col gap-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex-1">
              <p className="font-medium">Google Sheets</p>
              <p className="text-sm text-gray-500">
                Import your budget from Google Sheets. Connect your account, paste your sheet link or ID, map the columns and sync.
              </p>
            </div>
            <div className="flex items-center gap-3">
              {/* Enable toggle for sheet integration */}
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={!!connections.sheet?.enabled}
                  onChange={(e) => updateService('sheet', { enabled: e.target.checked })}
                />
                <span className="text-sm">Enable</span>
              </label>
              <span className={statusColor(connections.sheet?.status || 'not_connected')}>
                {formatStatus(connections.sheet?.status || 'not_connected')}
              </span>
            </div>
          </div>
          {connections.sheet?.enabled && (
            <>
              {/* Show mapping UI when a sheet has been loaded but not yet imported */}
              {mappingStep && sheetValues ? (
                <div className="space-y-3">
                  <p className="text-xs text-gray-500">
                    Select how each column should be mapped. Only rows with a Category and Budget value will be imported.
                  </p>
                  <div className="overflow-x-auto border border-gray-200 dark:border-gray-700 rounded-md">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-xs">
                      <thead className="bg-gray-50 dark:bg-gray-800">
                        <tr>
                          {sheetValues[0].map((cell, idx) => (
                            <th key={idx} className="p-1 align-bottom border-b border-gray-200 dark:border-gray-700">
                              <select
                                className="bg-transparent border border-gray-300 dark:border-gray-600 rounded-md px-1 py-0.5 text-xs"
                                value={columnMappings[idx] || 'Ignore'}
                                onChange={(e) => {
                                  const newMappings = [...columnMappings];
                                  newMappings[idx] = e.target.value as ColumnOption;
                                  setColumnMappings(newMappings);
                                }}
                              >
                                {COLUMN_OPTIONS.map((opt) => (
                                  <option key={opt} value={opt}>{opt}</option>
                                ))}
                              </select>
                              <div className="mt-1 font-semibold text-gray-700 dark:text-gray-300 truncate max-w-[120px]">
                                {cell || '(blank)'}
                              </div>
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {sheetValues.slice(1, 6).map((row, rIdx) => (
                          <tr key={rIdx} className="border-b border-gray-200 dark:border-gray-700">
                            {row.map((cell, cIdx) => (
                              <td key={cIdx} className="p-1 whitespace-nowrap max-w-[120px] truncate">
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="flex gap-2 items-center">
                    <button
                      onClick={handleImportSheet}
                      className="px-3 py-1 bg-primary text-white text-xs rounded-md hover:bg-primary-dark"
                    >
                      Import
                    </button>
                    <button
                      onClick={() => {
                        setMappingStep(false);
                        setSheetValues(null);
                      }}
                      className="px-3 py-1 bg-gray-200 dark:bg-gray-700 text-xs rounded-md hover:bg-gray-300 dark:hover:bg-gray-600"
                    >
                      Cancel
                    </button>
                    {sheetError && <span className="text-xs text-red-600">{sheetError}</span>}
                  </div>
                </div>
              ) : null}
              {/* Show connect sheet UI when not yet connected and not mapping */}
              {!mappingStep && connections.sheet?.status !== 'connected' && connections.calendar?.tokens && connections.calendar?.status === 'connected' && (
                <div className="space-y-2">
                  <label className="block text-xs font-medium">Google Sheets link or ID</label>
                  <input
                    type="text"
                    value={sheetUrl}
                    onChange={(e) => setSheetUrl(e.target.value)}
                    placeholder="Paste your sheet link or ID"
                    className="w-full bg-transparent border-b border-gray-300 dark:border-gray-600 py-1 text-sm focus:outline-none"
                  />
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleSheetConnect}
                      className="px-3 py-1 bg-primary text-white text-xs rounded-md hover:bg-primary-dark"
                      disabled={sheetLoading}
                    >
                      {sheetLoading ? 'Loading…' : 'Load sheet'}
                    </button>
                    {sheetError && <span className="text-xs text-red-600">{sheetError}</span>}
                  </div>
                </div>
              )}
              {/* Show connected sheet status */}
              {connections.sheet?.status === 'connected' && (
                <div className="flex flex-col gap-1">
                  <p className="text-xs text-gray-500">
                    Budget sheet connected. Last synced{' '}
                    {lastUpdated.sheet ? new Date(lastUpdated.sheet).toLocaleString() : 'never'}.
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={handleSheetRefresh}
                      className="px-3 py-1 bg-primary text-white text-xs rounded-md hover:bg-primary-dark"
                    >
                      Refresh Data
                    </button>
                    <button
                      onClick={handleSheetDisconnect}
                      className="px-3 py-1 bg-red-500 text-white text-xs rounded-md hover:bg-red-600"
                    >
                      Disconnect
                    </button>
                  </div>
                </div>
              )}
              {/* If calendar not connected, prompt to connect first */}
              {!mappingStep && connections.sheet?.status !== 'connected' && (!connections.calendar?.tokens || connections.calendar?.status !== 'connected') && (
                <p className="text-xs text-gray-500">
                  Connect your Google account above to select and import a budget sheet.
                </p>
              )}
            </>
          )}
        </div>
      </Card>

      {/* Market Data Integration */}
      <Card title="Market Data" className="space-y-4">
        <div className="flex flex-col gap-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex-1">
              <p className="font-medium">Market Data</p>
              <p className="text-sm text-gray-500">Fetch live quotes for your watchlist symbols.</p>
            </div>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={!!connections.market?.enabled}
                  onChange={(e) => updateService('market', { enabled: e.target.checked })}
                />
                <span className="text-sm">Enable</span>
              </label>
              <span className={statusColor(connections.market?.status || 'not_connected')}>
                {formatStatus(connections.market?.status)}
              </span>
            </div>
          </div>
          {connections.market?.enabled && (
            <div className="flex flex-col md:flex-row items-center gap-3">
              <div className="flex-1">
                <label className="block text-xs font-medium mb-1">API Key</label>
                <div className="flex items-center gap-2">
                  <input
                    type={showMarketKey ? 'text' : 'password'}
                    value={connections.market.key || ''}
                    onChange={(e) => updateService('market', { key: e.target.value, status: 'not_connected', error: undefined })}
                    placeholder="Enter your market API key"
                    className="flex-1 bg-transparent border-b border-gray-300 dark:border-gray-600 py-1 text-sm focus:outline-none"
                  />
                  <button
                    onClick={() => setShowMarketKey((prev) => !prev)}
                    className="text-xs text-primary underline"
                  >
                    {showMarketKey ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => testIntegration('market')}
                  className="px-3 py-1 bg-primary text-white text-xs rounded-md hover:bg-primary-dark"
                >
                  Test
                </button>
              </div>
            </div>
          )}
          {connections.market?.error && (
            <p className="text-xs text-red-600">{connections.market.error}</p>
          )}
        </div>
      </Card>

      {/* Verse Integration */}
      <Card title="Verse of the Day" className="space-y-4">
        <div className="flex flex-col gap-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex-1">
              <p className="font-medium">Bible Verse</p>
              <p className="text-sm text-gray-500">Show an inspirational verse on your Home page.</p>
            </div>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={!!connections.verse?.enabled}
                  onChange={(e) => updateService('verse', { enabled: e.target.checked })}
                />
                <span className="text-sm">Enable</span>
              </label>
              <span className={statusColor(connections.verse?.status || 'not_connected')}>
                {formatStatus(connections.verse?.status)}
              </span>
            </div>
          </div>
          {connections.verse?.enabled && (
            <div className="flex flex-col md:flex-row items-center gap-3">
              <div className="flex-1">
                <label className="block text-xs font-medium mb-1">API Source / Key</label>
                <div className="flex items-center gap-2">
                  <input
                    type={showVerseKey ? 'text' : 'password'}
                    value={connections.verse.key || ''}
                    onChange={(e) => updateService('verse', { key: e.target.value, status: 'not_connected', error: undefined })}
                    placeholder="Enter verse API endpoint or key"
                    className="flex-1 bg-transparent border-b border-gray-300 dark:border-gray-600 py-1 text-sm focus:outline-none"
                  />
                  <button
                    onClick={() => setShowVerseKey((prev) => !prev)}
                    className="text-xs text-primary underline"
                  >
                    {showVerseKey ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => testIntegration('verse')}
                  className="px-3 py-1 bg-primary text-white text-xs rounded-md hover:bg-primary-dark"
                >
                  Test
                </button>
              </div>
            </div>
          )}
          {connections.verse?.error && (
            <p className="text-xs text-red-600">{connections.verse.error}</p>
          )}
        </div>
      </Card>

      {/* Weather Integration */}
      <Card title="Weather" className="space-y-4">
        <div className="flex flex-col gap-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex-1">
              <p className="font-medium">Weather</p>
              <p className="text-sm text-gray-500">See current conditions for your city on Home.</p>
            </div>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={!!connections.weather?.enabled}
                  onChange={(e) => updateService('weather', { enabled: e.target.checked })}
                />
                <span className="text-sm">Enable</span>
              </label>
              <span className={statusColor(connections.weather?.status || 'not_connected')}>
                {formatStatus(connections.weather?.status)}
              </span>
            </div>
          </div>
          {connections.weather?.enabled && (
            <div className="flex flex-col md:flex-row items-center gap-3">
              <div className="flex-1">
                <label className="block text-xs font-medium mb-1">API Key</label>
                <div className="flex items-center gap-2">
                  <input
                    type={showWeatherKey ? 'text' : 'password'}
                    value={connections.weather.key || ''}
                    onChange={(e) => updateService('weather', { key: e.target.value, status: 'not_connected', error: undefined })}
                    placeholder="Enter your weather API key"
                    className="flex-1 bg-transparent border-b border-gray-300 dark:border-gray-600 py-1 text-sm focus:outline-none"
                  />
                  <button
                    onClick={() => setShowWeatherKey((prev) => !prev)}
                    className="text-xs text-primary underline"
                  >
                    {showWeatherKey ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => testIntegration('weather')}
                  className="px-3 py-1 bg-primary text-white text-xs rounded-md hover:bg-primary-dark"
                >
                  Test
                </button>
              </div>
            </div>
          )}
          {connections.weather?.error && (
            <p className="text-xs text-red-600">{connections.weather.error}</p>
          )}
        </div>
      </Card>

      <p className="text-xs text-gray-500 italic">You can connect or disconnect services any time. Settings are stored locally on your device.</p>
    </div>
  );
}