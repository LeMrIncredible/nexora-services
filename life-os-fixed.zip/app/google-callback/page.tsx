"use client";

import { useSearchParams, useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useData } from '../context';

/**
 * This page handles the redirect from Google after the OAuth flow. It
 * extracts the authorisation code from the query string, calls our
 * backend to exchange it for tokens, stores those tokens in the
 * connections state for both the calendar and sheet integrations and
 * then navigates back to the Connections page. While processing it
 * shows a simple loading message.
 */
export default function GoogleCallbackPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { connections, setConnections } = useData();

  useEffect(() => {
    const code = searchParams.get('code');
    const redirectUri = searchParams.get('redirectUri') || undefined;
    async function handleAuth() {
      if (!code) {
        router.replace('/connections');
        return;
      }
      try {
        const res = await fetch(`/api/google/callback?code=${encodeURIComponent(code)}${
          redirectUri ? `&redirectUri=${encodeURIComponent(redirectUri)}` : ''
        }`);
        const data = await res.json();
        if (data.tokens) {
          // Merge tokens into calendar and sheet credentials. Retain
          // existing settings like enabled and key. Tokens may contain
          // access_token, refresh_token and expiry_date.
          const updatedCalendar = {
            ...connections.calendar,
            tokens: data.tokens,
            status: 'connected',
          };
          const updatedSheet = {
            ...connections.sheet,
            tokens: data.tokens,
            status: connections.sheet?.status === 'connected' ? 'connected' : 'not_connected',
          };
          setConnections({
            ...connections,
            calendar: updatedCalendar,
            sheet: updatedSheet,
          });
        }
      } catch (err) {
        console.error('Google OAuth callback processing error', err);
      } finally {
        router.replace('/connections');
      }
    }
    handleAuth();
  }, [searchParams]);

  return (
    <div className="flex h-screen items-center justify-center">
      <p className="text-sm text-gray-500">Connecting your Google account…</p>
    </div>
  );
}