"use client";

import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import type {
  MoneyData,
  HousePlanData,
  Task,
  Opportunity,
  TradingIdea,
  ConnectionsData,
  CalendarEvent,
  EmailSummary,
  MarketQuote,
  ChatMessage,
  Recommendation,
  Notification,
  DailyBrief,
  AutomationSettings,
} from '../types';
import {
  moneySeed,
  houseSeed,
  tasksSeed,
  opportunitiesSeed,
  tradingSeed,
  connectionsSeed,
  calendarSeed,
  emailsSeed,
  marketSeed,
  chatSeed,
  recommendationsSeed,
  notificationsSeed,
  dailyBriefSeed,
  automationSettingsSeed,
} from '../utils/seedData';
import { loadState, saveState } from '../utils/persistence';

// Define shape of our global state
interface DataContextValue {
  money: MoneyData;
  setMoney: (data: MoneyData) => void;
  house: HousePlanData;
  setHouse: (data: HousePlanData) => void;
  tasks: Task[];
  setTasks: (data: Task[]) => void;
  opportunities: Opportunity[];
  setOpportunities: (data: Opportunity[]) => void;
  trading: TradingIdea[];
  setTrading: (data: TradingIdea[]) => void;
  // Brain layer state
  connections: ConnectionsData;
  setConnections: (data: ConnectionsData) => void;
  calendarEvents: CalendarEvent[];
  setCalendarEvents: (data: CalendarEvent[]) => void;
  emails: EmailSummary[];
  setEmails: (data: EmailSummary[]) => void;
  market: MarketQuote[];
  setMarket: (data: MarketQuote[]) => void;
  chat: ChatMessage[];
  setChat: (data: ChatMessage[]) => void;
  recommendations: Recommendation[];
  setRecommendations: (data: Recommendation[]) => void;

  // Automation layer state
  notifications: Notification[];
  setNotifications: (data: Notification[]) => void;
  dailyBrief: DailyBrief | null;
  setDailyBrief: (data: DailyBrief | null) => void;
  automationSettings: AutomationSettings;
  setAutomationSettings: (data: AutomationSettings) => void;
  /**
   * Track the last time each integration was refreshed. This helps
   * display timestamps on the Home page and avoid unnecessary refreshes.
   */
  lastUpdated: Record<string, string>;
  setLastUpdated: (data: Record<string, string>) => void;
}

const DataContext = createContext<DataContextValue | undefined>(undefined);

// Note: `getStored` has been replaced by the versioned persistence helpers in
// utils/persistence. The function definition is retained for backwards
// compatibility but simply proxies through to `loadState`. Leaving this
// function in place avoids import churn across the rest of the codebase.
function getStored<T>(key: string, seed: T): T {
  return loadState(key, seed);
}

export function DataProvider({ children }: { children: ReactNode }) {
  const [money, setMoney] = useState<MoneyData>(() => loadState('money', moneySeed));
  const [house, setHouse] = useState<HousePlanData>(() => loadState('house', houseSeed));
  const [tasks, setTasks] = useState<Task[]>(() => loadState('tasks', tasksSeed));
  const [opportunities, setOpportunities] = useState<Opportunity[]>(() => loadState('opportunities', opportunitiesSeed));
  const [trading, setTrading] = useState<TradingIdea[]>(() => loadState('trading', tradingSeed));
  const [connections, setConnections] = useState<ConnectionsData>(() => loadState('connections', connectionsSeed));
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(() => loadState('calendar', calendarSeed));
  const [emails, setEmails] = useState<EmailSummary[]>(() => loadState('emails', emailsSeed));
  const [market, setMarket] = useState<MarketQuote[]>(() => loadState('market', marketSeed));
  const [chat, setChat] = useState<ChatMessage[]>(() => loadState('chat', chatSeed));
  const [recommendations, setRecommendations] = useState<Recommendation[]>(() => loadState('recommendations', recommendationsSeed));

  // New states for automation, notifications and daily brief
  const [notifications, setNotifications] = useState<Notification[]>(() => loadState('notifications', notificationsSeed));
  const [dailyBrief, setDailyBrief] = useState<DailyBrief | null>(() => loadState('dailyBrief', dailyBriefSeed));
  const [automationSettings, setAutomationSettings] = useState<AutomationSettings>(() => loadState('automationSettings', automationSettingsSeed));
  const [lastUpdated, setLastUpdated] = useState<Record<string, string>>(() => loadState('lastUpdated', {}));

  // Persist state changes to localStorage
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('money', money);
  }, [money]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('house', house);
  }, [house]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('tasks', tasks);
  }, [tasks]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('opportunities', opportunities);
  }, [opportunities]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('trading', trading);
  }, [trading]);
  // Persist brain layer state changes
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('connections', connections);
  }, [connections]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('calendar', calendarEvents);
  }, [calendarEvents]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('emails', emails);
  }, [emails]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('market', market);
  }, [market]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('chat', chat);
  }, [chat]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('recommendations', recommendations);
  }, [recommendations]);

  // Persist automation-related state
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('notifications', notifications);
  }, [notifications]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('dailyBrief', dailyBrief);
  }, [dailyBrief]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('automationSettings', automationSettings);
  }, [automationSettings]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    saveState('lastUpdated', lastUpdated);
  }, [lastUpdated]);

  return (
    <DataContext.Provider
      value={{
        money,
        setMoney,
        house,
        setHouse,
        tasks,
        setTasks,
        opportunities,
        setOpportunities,
        trading,
        setTrading,
        connections,
        setConnections,
        calendarEvents,
        setCalendarEvents,
        emails,
        setEmails,
        market,
        setMarket,
        chat,
        setChat,
        recommendations,
        setRecommendations,
        notifications,
        setNotifications,
        dailyBrief,
        setDailyBrief,
        automationSettings,
        setAutomationSettings,
        lastUpdated,
        setLastUpdated,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within a DataProvider');
  return ctx;
}