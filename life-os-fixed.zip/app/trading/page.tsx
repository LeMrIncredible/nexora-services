"use client";

import { useState } from 'react';
import { useData } from '../context';
import Card from '../../components/Card';

export default function TradingPage() {
  const { trading, setTrading, market } = useData();
  const [form, setForm] = useState({ symbol: '', entry: 0, target: 0, stop: 0, conviction: 0.5, notes: '' });

  const addIdea = () => {
    if (!form.symbol) return;
    const id = Date.now().toString();
    setTrading([...trading, { id, ...form }]);
    setForm({ symbol: '', entry: 0, target: 0, stop: 0, conviction: 0.5, notes: '' });
  };

  const removeIdea = (id: string) => {
    setTrading(trading.filter((i) => i.id !== id));
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Trading Ideas</h1>

      {/* Form to add a new trading idea */}
      <Card title="Add Idea" className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
          <input
            type="text"
            placeholder="Symbol"
            value={form.symbol}
            onChange={(e) => setForm({ ...form, symbol: e.target.value.toUpperCase() })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="number"
            placeholder="Entry"
            value={form.entry}
            onChange={(e) => setForm({ ...form, entry: parseFloat(e.target.value) || 0 })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="number"
            placeholder="Target"
            value={form.target}
            onChange={(e) => setForm({ ...form, target: parseFloat(e.target.value) || 0 })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="number"
            placeholder="Stop"
            value={form.stop}
            onChange={(e) => setForm({ ...form, stop: parseFloat(e.target.value) || 0 })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="number"
            step="0.1"
            min="0"
            max="1"
            placeholder="Conviction (0–1)"
            value={form.conviction}
            onChange={(e) => setForm({ ...form, conviction: parseFloat(e.target.value) || 0 })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="text"
            placeholder="Notes"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            className="md:col-span-2 bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <button
            className="md:col-span-1 px-4 py-2 bg-primary text-white text-sm rounded-md hover:bg-primary-dark"
            onClick={addIdea}
          >
            Add
          </button>
        </div>
      </Card>

      {/* Watchlist rendered as a list rather than a table */}
      <Card title="Watchlist" className="space-y-4">
        {trading.length > 0 ? (
          <div className="space-y-4">
            {trading.map((idea) => (
              <div
                key={idea.id}
                className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 p-3 border border-gray-200 dark:border-gray-700 rounded-md"
              >
                <div className="flex-1">
                  <p className="font-semibold text-lg">{idea.symbol}</p>
                  <div className="flex flex-wrap gap-4 text-sm mt-1">
                    <span>Entry: <span className="font-medium">${idea.entry.toFixed(2)}</span></span>
                    <span>Target: <span className="font-medium">${idea.target.toFixed(2)}</span></span>
                    <span>Stop: <span className="font-medium">${idea.stop.toFixed(2)}</span></span>
                    <span>Conviction: <span className="font-medium">{(idea.conviction * 100).toFixed(0)}%</span></span>
                    {/* Live price and change if market data is available */}
                    {market && market.length > 0 && (
                      (() => {
                        const quote = market.find((q) => q.symbol.toUpperCase() === idea.symbol.toUpperCase());
                        if (!quote) return null;
                        return (
                          <>
                            <span>Price: <span className="font-medium">${quote.price.toFixed(2)}</span></span>
                            <span>Change: <span className={quote.change >= 0 ? 'font-medium text-green-600' : 'font-medium text-red-600'}>{quote.change >= 0 ? '+' : ''}{quote.change.toFixed(2)}</span></span>
                          </>
                        );
                      })()
                    )}
                  </div>
                  {idea.notes && <p className="text-xs italic text-gray-400 mt-1">{idea.notes}</p>}
                </div>
                <div className="flex-shrink-0">
                  <button
                    className="text-xs text-red-500 hover:underline"
                    onClick={() => removeIdea(idea.id)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-gray-500">No trading ideas yet. Add one above to start tracking opportunities.</p>
        )}
      </Card>
    </div>
  );
}