import './globals.css';
import { ReactNode } from 'react';
import ClientLayout from './ClientLayout';

export const metadata = {
  title: 'Life OS',
  description: 'A personal dashboard and decision‑making tool',
};

/**
 * RootLayout is a server component that wraps all pages in the app.
 * It renders the HTML and body tags and defers any client‑side logic to
 * ClientLayout. Keeping this component free of hooks ensures it
 * complies with Next.js server component rules.
 */
export default function RootLayout({ children }: { children: ReactNode }) {
  // The default theme class is set to dark; ClientLayout will update this
  // on the client side based on the persisted theme value.
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen flex flex-col">
        <ClientLayout>{children}</ClientLayout>
      </body>
    </html>
  );
}