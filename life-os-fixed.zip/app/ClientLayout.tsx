"use client";

import { ReactNode, useEffect, useState } from 'react';
import { DataProvider } from './context';
import NavBar from '../components/NavBar';
import AutomationRunner from '../components/AutomationRunner';

/**
 * ClientLayout is a wrapper component used within the root server layout. It
 * encapsulates all client‑side logic that relies on React hooks such as
 * useState or useEffect. This separation allows the root layout to remain
 * a server component while still supporting theme toggling, context
 * providers, and background automation. The layout also renders the
 * navigation bar and the primary content area.
 */
export default function ClientLayout({ children }: { children: ReactNode }) {
  // Manage theme (light or dark) using localStorage. Default to dark on
  // initial render. Once mounted, the effect will synchronise the DOM
  // class with the persisted theme value.
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window === 'undefined') return 'dark';
    return (localStorage.getItem('theme') as 'light' | 'dark') || 'dark';
  });

  useEffect(() => {
    const root = window.document.documentElement;
    // Remove the opposite theme class and apply the current one
    root.classList.remove(theme === 'dark' ? 'light' : 'dark');
    root.classList.add(theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  return (
    <DataProvider>
      {/* Run background automation tasks */}
      <AutomationRunner />
      {/* Top navigation */}
      <NavBar />
      {/* Main page content */}
      <main className="flex-1 p-4 max-w-5xl mx-auto w-full space-y-4">
        {children}
      </main>
    </DataProvider>
  );
}