"use client";

import { useState, useMemo } from 'react';
import { useData } from '../context';
import Card from '../../components/Card';

export default function OpportunitiesPage() {
  const { opportunities, setOpportunities } = useData();
  const [form, setForm] = useState({
    title: '',
    type: '',
    estimatedValue: 0,
    effort: 5,
    urgency: 5,
    notes: '',
  });

  const addOpportunity = () => {
    if (!form.title) return;
    const id = Date.now().toString();
    setOpportunities([
      ...opportunities,
      { id, ...form, status: 'todo' as const, estimatedValue: Number(form.estimatedValue), effort: Number(form.effort), urgency: Number(form.urgency) },
    ]);
    setForm({ title: '', type: '', estimatedValue: 0, effort: 5, urgency: 5, notes: '' });
  };

  const updateStatus = (id: string, status: 'todo' | 'in-progress' | 'done') => {
    setOpportunities(opportunities.map((o) => (o.id === id ? { ...o, status } : o)));
  };

  const bestOpportunity = useMemo(() => {
    return opportunities
      .filter((o) => o.status !== 'done')
      .sort((a, b) => ((b.estimatedValue * b.urgency) / b.effort) - ((a.estimatedValue * a.urgency) / a.effort))[0];
  }, [opportunities]);

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Opportunities</h1>

      {/* Highlight the best opportunity based on value, urgency, and effort */}
      <Card title="Best Opportunity Today" className="space-y-3">
        {bestOpportunity ? (
          <div className="space-y-1">
            <p className="text-lg font-semibold">{bestOpportunity.title}</p>
            <p className="text-sm text-gray-500">{bestOpportunity.type}</p>
            <div className="flex gap-6 text-sm">
              <span>Value: <span className="font-medium">${bestOpportunity.estimatedValue.toLocaleString()}</span></span>
              <span>Effort: <span className="font-medium">{bestOpportunity.effort}</span></span>
              <span>Urgency: <span className="font-medium">{bestOpportunity.urgency}</span></span>
            </div>
            {bestOpportunity.notes && (
              <p className="text-xs italic text-gray-400">{bestOpportunity.notes}</p>
            )}
          </div>
        ) : (
          <p className="text-sm text-gray-500">No active opportunities right now.</p>
        )}
      </Card>

      {/* Form to add a new opportunity */}
      <Card title="Add Opportunity" className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
          <input
            type="text"
            placeholder="Title"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="md:col-span-2 bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="text"
            placeholder="Type"
            value={form.type}
            onChange={(e) => setForm({ ...form, type: e.target.value })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="number"
            placeholder="Value"
            value={form.estimatedValue}
            onChange={(e) => setForm({ ...form, estimatedValue: parseFloat(e.target.value) || 0 })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="number"
            placeholder="Effort (1–10)"
            value={form.effort}
            onChange={(e) => setForm({ ...form, effort: parseInt(e.target.value) || 1 })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="number"
            placeholder="Urgency (1–10)"
            value={form.urgency}
            onChange={(e) => setForm({ ...form, urgency: parseInt(e.target.value) || 1 })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="text"
            placeholder="Notes"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            className="md:col-span-2 bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <button
            className="md:col-span-1 px-4 py-2 bg-primary text-white text-sm rounded-md hover:bg-primary-dark"
            onClick={addOpportunity}
          >
            Add
          </button>
        </div>
      </Card>

      {/* List of all opportunities */}
      <Card title="All Opportunities" className="space-y-4">
        {opportunities.length > 0 ? (
          <div className="space-y-4">
            {opportunities.map((o) => (
              <div
                key={o.id}
                className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 p-3 border border-gray-200 dark:border-gray-700 rounded-md"
              >
                <div className="flex-1">
                  <p className="font-semibold">{o.title}</p>
                  <p className="text-xs text-gray-500">{o.type}</p>
                  {o.notes && <p className="text-xs italic text-gray-400 mt-1">{o.notes}</p>}
                </div>
                <div className="flex flex-wrap gap-4 text-sm">
                  <span>Value: <span className="font-medium">${o.estimatedValue.toLocaleString()}</span></span>
                  <span>Effort: <span className="font-medium">{o.effort}</span></span>
                  <span>Urgency: <span className="font-medium">{o.urgency}</span></span>
                  <span>
                    <select
                      className="bg-transparent border-b border-gray-300 dark:border-gray-600 text-sm focus:outline-none"
                      value={o.status}
                      onChange={(e) => updateStatus(o.id, e.target.value as any)}
                    >
                      <option value="todo">To Do</option>
                      <option value="in-progress">In Progress</option>
                      <option value="done">Done</option>
                    </select>
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-gray-500">You have no opportunities yet. Add one above to get started.</p>
        )}
      </Card>
    </div>
  );
}