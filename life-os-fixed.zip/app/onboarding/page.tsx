"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useData } from '../context';
import Card from '../../components/Card';

/**
 * OnboardingPage presents a simple multi‑step wizard to help new users
 * configure core parts of Life OS on first run. It collects a few
 * preferences, allows the user to review and adjust budget values, and
 * enables or disables key integrations. When finished it updates the
 * global state and marks onboarding as complete in localStorage.
 */
export default function OnboardingPage() {
  const router = useRouter();
  const {
    money,
    setMoney,
    connections,
    setConnections,
  } = useData();

  const [step, setStep] = useState(0);
  // Preference state
  const [showVersePref, setShowVersePref] = useState(() => {
    if (typeof window === 'undefined') return true;
    const val = localStorage.getItem('showVerse');
    return val !== 'false';
  });
  // Budget adjustments
  const [weeklyBudget, setWeeklyBudget] = useState(() => money.weeklyBudget.toFixed(2));
  // Integration toggles/keys
  const [openaiEnabled, setOpenaiEnabled] = useState<boolean>(connections.openai?.enabled || false);
  const [gmailEnabled, setGmailEnabled] = useState<boolean>(connections.gmail?.enabled || false);
  const [calendarEnabled, setCalendarEnabled] = useState<boolean>(connections.calendar?.enabled || false);
  const [marketEnabled, setMarketEnabled] = useState<boolean>(connections.market?.enabled || false);
  const [verseEnabled, setVerseEnabled] = useState<boolean>(connections.verse?.enabled || false);
  const [weatherEnabled, setWeatherEnabled] = useState<boolean>(connections.weather?.enabled || false);

  // API key values captured during onboarding. Prepopulate from existing connections if available.
  const [openaiKey, setOpenaiKey] = useState<string>(connections.openai?.key || '');
  const [marketKey, setMarketKey] = useState<string>(connections.market?.key || '');
  const [verseKey, setVerseKey] = useState<string>(connections.verse?.key || '');
  const [weatherKey, setWeatherKey] = useState<string>(connections.weather?.key || '');
  // Show/hide toggles for secrets
  const [showOpenaiKey, setShowOpenaiKey] = useState(false);
  const [showMarketKey, setShowMarketKey] = useState(false);
  const [showVerseKey, setShowVerseKey] = useState(false);
  const [showWeatherKey, setShowWeatherKey] = useState(false);

  const steps = [
    {
      title: 'Welcome',
      content: (
        <Card title="Welcome to Life OS" className="space-y-4">
          <p className="text-sm text-gray-500">
            Life OS is your personal operating system. We’ll guide you through a few
            quick steps to configure your dashboard. You can skip any step and adjust
            settings later.
          </p>
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={showVersePref}
                onChange={(e) => setShowVersePref(e.target.checked)}
              />
              <span className="text-sm">Show verse of the day</span>
            </label>
          </div>
        </Card>
      ),
    },
    {
      title: 'Budget Setup',
      content: (
        <Card title="Budget Setup" className="space-y-4">
          <p className="text-sm text-gray-500">Review or adjust your weekly budget. This value is used to calculate safe‑to‑spend amounts.</p>
          <div className="flex items-center gap-3">
            <label className="text-sm">Weekly Budget:</label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={weeklyBudget}
              onChange={(e) => setWeeklyBudget(e.target.value)}
              className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1 w-32"
            />
          </div>
        </Card>
      ),
    },
    {
      title: 'Connect Services',
      content: (
        <Card title="Connect Services" className="space-y-6">
          {/* OpenAI */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="font-medium">OpenAI</p>
                <p className="text-xs text-gray-500">Enables the chat assistant and smart summaries.</p>
              </div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={openaiEnabled}
                  onChange={(e) => setOpenaiEnabled(e.target.checked)}
                />
                <span className="text-sm">Enable</span>
              </label>
            </div>
            {openaiEnabled && (
              <div className="flex flex-col gap-2">
                <label className="text-xs font-medium" htmlFor="openai-key">OpenAI API Key</label>
                <div className="flex items-center gap-2">
                  <input
                    id="openai-key"
                    type={showOpenaiKey ? 'text' : 'password'}
                    className="flex-1 bg-transparent border-b border-gray-300 dark:border-gray-600 py-1 text-sm focus:outline-none"
                    placeholder="Enter your OpenAI key"
                    value={openaiKey}
                    onChange={(e) => setOpenaiKey(e.target.value)}
                  />
                    <button
                      type="button"
                      onClick={() => setShowOpenaiKey((prev) => !prev)}
                      className="text-xs text-primary underline"
                    >
                      {showOpenaiKey ? 'Hide' : 'Show'}
                    </button>
                </div>
                <p className="text-xs text-gray-500">Your key is stored locally and used to call OpenAI’s API.</p>
              </div>
            )}
          </div>
          {/* Email integration placeholder */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="font-medium">Email</p>
                <p className="text-xs text-gray-500">Gmail integration is coming soon.</p>
              </div>
              <span className="text-sm text-gray-400">Not available</span>
            </div>
          </div>
          {/* Calendar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="font-medium">Google Calendar</p>
                <p className="text-xs text-gray-500">Display your upcoming events.</p>
              </div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={calendarEnabled}
                  onChange={(e) => setCalendarEnabled(e.target.checked)}
                />
                <span className="text-sm">Enable</span>
              </label>
            </div>
            {calendarEnabled && (
              <p className="text-xs text-gray-500">You’ll be prompted to connect your Google account after setup.</p>
            )}
          </div>
          {/* Market Data */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="font-medium">Market Data</p>
                <p className="text-xs text-gray-500">Pull live prices for your watchlist.</p>
              </div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={marketEnabled}
                  onChange={(e) => setMarketEnabled(e.target.checked)}
                />
                <span className="text-sm">Enable</span>
              </label>
            </div>
            {marketEnabled && (
              <div className="flex flex-col gap-2">
                <label className="text-xs font-medium" htmlFor="market-key">Market API Key</label>
                <div className="flex items-center gap-2">
                  <input
                    id="market-key"
                    type={showMarketKey ? 'text' : 'password'}
                    className="flex-1 bg-transparent border-b border-gray-300 dark:border-gray-600 py-1 text-sm focus:outline-none"
                    placeholder="Enter your market API key"
                    value={marketKey}
                    onChange={(e) => setMarketKey(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowMarketKey((prev) => !prev)}
                    className="text-xs text-primary underline"
                  >
                    {showMarketKey ? 'Hide' : 'Show'}
                  </button>
                </div>
                <p className="text-xs text-gray-500">Used to fetch real‑time market data.</p>
              </div>
            )}
          </div>
          {/* Verse */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="font-medium">Bible Verse</p>
                <p className="text-xs text-gray-500">Show a verse of the day on your dashboard.</p>
              </div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={verseEnabled}
                  onChange={(e) => setVerseEnabled(e.target.checked)}
                />
                <span className="text-sm">Enable</span>
              </label>
            </div>
            {verseEnabled && (
              <div className="flex flex-col gap-2">
                <label className="text-xs font-medium" htmlFor="verse-key">Verse API Source/Key</label>
                <div className="flex items-center gap-2">
                  <input
                    id="verse-key"
                    type={showVerseKey ? 'text' : 'password'}
                    className="flex-1 bg-transparent border-b border-gray-300 dark:border-gray-600 py-1 text-sm focus:outline-none"
                    placeholder="Enter verse API endpoint or key"
                    value={verseKey}
                    onChange={(e) => setVerseKey(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowVerseKey((prev) => !prev)}
                    className="text-xs text-primary underline"
                  >
                    {showVerseKey ? 'Hide' : 'Show'}
                  </button>
                </div>
                <p className="text-xs text-gray-500">Leave blank to use the built‑in verse rotation.</p>
              </div>
            )}
          </div>
          {/* Weather */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="font-medium">Weather</p>
                <p className="text-xs text-gray-500">Show current conditions for your city.</p>
              </div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={weatherEnabled}
                  onChange={(e) => setWeatherEnabled(e.target.checked)}
                />
                <span className="text-sm">Enable</span>
              </label>
            </div>
            {weatherEnabled && (
              <div className="flex flex-col gap-2">
                <label className="text-xs font-medium" htmlFor="weather-key">Weather API Key</label>
                <div className="flex items-center gap-2">
                  <input
                    id="weather-key"
                    type={showWeatherKey ? 'text' : 'password'}
                    className="flex-1 bg-transparent border-b border-gray-300 dark:border-gray-600 py-1 text-sm focus:outline-none"
                    placeholder="Enter your weather API key"
                    value={weatherKey}
                    onChange={(e) => setWeatherKey(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowWeatherKey((prev) => !prev)}
                    className="text-xs text-primary underline"
                  >
                    {showWeatherKey ? 'Hide' : 'Show'}
                  </button>
                </div>
                <p className="text-xs text-gray-500">Used to fetch real‑time weather.</p>
              </div>
            )}
          </div>
        </Card>
      ),
    },
    {
      title: 'Ready to Go',
      content: (
        <Card title="You're all set!" className="space-y-4">
          <p className="text-sm text-gray-500">
            You've completed the setup. Below is a summary of your preferences and integrations. You can adjust these at any time under Connections or Settings.
          </p>
          <ul className="space-y-1 text-sm">
            <li>Verse of the day: {showVersePref ? 'Shown' : 'Hidden'}</li>
            <li>Weekly budget: ${parseFloat(weeklyBudget || '0').toFixed(2)}</li>
            <li>AI Assistant (OpenAI): {openaiEnabled ? (openaiKey ? 'Configured' : 'Not configured') : 'Disabled'}</li>
            <li>Email: Coming soon</li>
            <li>Google Calendar: {calendarEnabled ? 'Enabled' : 'Disabled'}</li>
            <li>Market Data: {marketEnabled ? (marketKey ? 'Configured' : 'Not configured') : 'Disabled'}</li>
            <li>Bible Verse: {verseEnabled ? (verseKey ? 'Configured' : 'Not configured') : 'Disabled'}</li>
            <li>Weather: {weatherEnabled ? (weatherKey ? 'Configured' : 'Not configured') : 'Disabled'}</li>
          </ul>
        </Card>
      ),
    },
  ];

  const handleFinish = () => {
    // Persist verse preference
    if (typeof window !== 'undefined') {
      localStorage.setItem('showVerse', showVersePref ? 'true' : 'false');
      localStorage.setItem('onboarded', 'true');
    }
    // Update money budget and safeToSpend
    const newWeeklyBudget = parseFloat(weeklyBudget || '0');
    // Recalculate safe to spend based on the new weekly budget and current weekly spending
    const newSafeToSpend = newWeeklyBudget - money.weeklySpending;
    setMoney({
      ...money,
      weeklyBudget: newWeeklyBudget,
      safeToSpend: newSafeToSpend,
    });
    // Build updated connections object. Store the API keys entered during
    // onboarding along with the enabled flags. Statuses remain as they
    // currently are and will be updated later via the test functions in
    // the Connections page or by the hooks when data is fetched.
    const newConnections = {
      ...connections,
      openai: { ...connections.openai, enabled: openaiEnabled, key: openaiKey },
      gmail: { ...connections.gmail, enabled: gmailEnabled },
      calendar: { ...connections.calendar, enabled: calendarEnabled },
      market: { ...connections.market, enabled: marketEnabled, key: marketKey },
      verse: { ...connections.verse, enabled: verseEnabled, key: verseKey },
      weather: { ...connections.weather, enabled: weatherEnabled, key: weatherKey },
    } as ConnectionsData;
    setConnections(newConnections);
    // Redirect to home
    router.push('/');
  };

  return (
    <div className="space-y-8 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold">Setup</h1>
      <p className="text-sm text-gray-500">Step {step + 1} of {steps.length}: {steps[step].title}</p>
      {/* Progress bar shows how far you are through the onboarding flow. It
          smoothly animates as the step changes. */}
      <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <div
          className="h-full bg-primary transition-all duration-300"
          style={{ width: `${(step) / (steps.length - 1) * 100}%` }}
        ></div>
      </div>
      {steps[step].content}
      <div className="flex justify-between mt-4">
        {step > 0 ? (
          <button
            onClick={() => setStep(step - 1)}
            className="px-4 py-2 text-sm rounded-md border border-gray-300 dark:border-gray-600 bg-transparent hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            Back
          </button>
        ) : (
          <span />
        )}
        {step < steps.length - 1 ? (
          <div className="flex gap-2">
            <button
              onClick={() => {
                // allow skipping to finish
                setStep(steps.length - 1);
              }}
              className="px-4 py-2 text-sm rounded-md border border-gray-300 dark:border-gray-600 bg-transparent hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              Skip
            </button>
            <button
              onClick={() => setStep(step + 1)}
              className="px-4 py-2 bg-primary text-white text-sm rounded-md hover:bg-primary-dark"
            >
              Next
            </button>
          </div>
        ) : (
          <button
            onClick={handleFinish}
            className="px-4 py-2 bg-primary text-white text-sm rounded-md hover:bg-primary-dark"
          >
            Get Started
          </button>
        )}
      </div>
      <p className="text-xs text-gray-500 mt-4">Your data stays on your device. You can change these settings later.</p>
    </div>
  );
}