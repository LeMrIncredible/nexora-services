"use client";

import { useState, useMemo } from 'react';
import { useData } from '../context';
import Card from '../../components/Card';

export default function TasksPage() {
  const { tasks, setTasks } = useData();
  const [newTask, setNewTask] = useState({
    title: '',
    category: '',
    dueDate: '',
    priority: 'medium' as const,
  });

  // Add a new task with a generated id and default status. Clear the form
  // after adding so users can quickly add another.
  const addTask = () => {
    if (!newTask.title) return;
    const id = Date.now().toString();
    setTasks([...tasks, { id, ...newTask, status: 'todo' }]);
    setNewTask({ title: '', category: '', dueDate: '', priority: 'medium' });
  };

  // Update status of an individual task. Supports moving between to do,
  // in progress, and done.
  const updateStatus = (id: string, status: 'todo' | 'in-progress' | 'done') => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, status } : t)));
  };

  // Categorize tasks by time horizon. Also filter out completed tasks from
  // active buckets so they only appear in the Completed section. A task
  // is considered due today if its due date matches the current date.
  const categorized = useMemo(() => {
    const today = new Date();
    const weekFromNow = new Date();
    weekFromNow.setDate(today.getDate() + 7);
    return {
      today: tasks.filter(
        (t) =>
          t.dueDate &&
          new Date(t.dueDate).toDateString() === today.toDateString() &&
          t.status !== 'done'
      ),
      thisWeek: tasks.filter(
        (t) =>
          t.dueDate &&
          new Date(t.dueDate) > today &&
          new Date(t.dueDate) <= weekFromNow &&
          t.status !== 'done'
      ),
      later: tasks.filter(
        (t) =>
          (!t.dueDate || new Date(t.dueDate) > weekFromNow) && t.status !== 'done'
      ),
      done: tasks.filter((t) => t.status === 'done'),
    };
  }, [tasks]);

  // Determine top three tasks by priority and due date. This helps
  // surface the most important items at a glance. Same logic as the
  // home page: high priority tasks come first, then sorted by date.
  const topTasks = useMemo(() => {
    const priorityOrder: Record<string, number> = { high: 1, medium: 2, low: 3 };
    return [...tasks]
      .filter((t) => t.status !== 'done')
      .sort((a, b) => {
        const pa = priorityOrder[a.priority];
        const pb = priorityOrder[b.priority];
        if (pa !== pb) return pa - pb;
        if (a.dueDate && b.dueDate) return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        return 0;
      })
      .slice(0, 3);
  }, [tasks]);

  // Render a list of tasks as a vertical list. Each item shows the task
  // title, due date, category and a status selector or done marker.
  const renderTaskList = (list: typeof tasks) => (
    <ul className="space-y-2">
      {list.map((task) => (
        <li key={task.id} className="flex justify-between items-start py-1">
          <div className="flex-1">
            <p className="font-medium">{task.title}</p>
            {task.dueDate && (
              <p className="text-xs text-gray-500">Due {new Date(task.dueDate).toLocaleDateString()}</p>
            )}
            <p className="text-xs text-gray-400 italic">{task.category}</p>
          </div>
          <div className="flex items-center gap-2 ml-4">
            {task.status !== 'done' ? (
              <select
                className="bg-transparent border-b border-gray-300 dark:border-gray-700 text-sm focus:outline-none"
                value={task.status}
                onChange={(e) => updateStatus(task.id, e.target.value as any)}
              >
                <option value="todo">To Do</option>
                <option value="in-progress">In Progress</option>
                <option value="done">Done</option>
              </select>
            ) : (
              <span className="text-xs text-green-500">✓ Done</span>
            )}
          </div>
        </li>
      ))}
    </ul>
  );

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Tasks</h1>
      {/* Quick add form for new tasks */}
      <Card title="Add Task" className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <input
            type="text"
            placeholder="Task description"
            value={newTask.title}
            onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
            className="md:col-span-2 bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="text"
            placeholder="Category"
            value={newTask.category}
            onChange={(e) => setNewTask({ ...newTask, category: e.target.value })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <input
            type="date"
            value={newTask.dueDate}
            onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          />
          <select
            value={newTask.priority}
            onChange={(e) => setNewTask({ ...newTask, priority: e.target.value as any })}
            className="bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
          >
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <button
            className="px-4 py-2 bg-primary text-white text-sm rounded-md hover:bg-primary-dark"
            onClick={addTask}
          >
            Add
          </button>
        </div>
      </Card>

      {/* Top 3 tasks call-out */}
      <Card title="Top Priorities" className="space-y-3">
        {topTasks.length > 0 ? (
          <ul className="space-y-2">
            {topTasks.map((task) => (
              <li key={task.id} className="flex justify-between items-baseline">
                <span className="font-semibold">{task.title}</span>
                {task.dueDate && (
                  <span className="text-xs text-gray-500">{new Date(task.dueDate).toLocaleDateString()}</span>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-gray-500">You have no tasks right now.</p>
        )}
      </Card>

      {/* Task categories grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Today" className="space-y-3">
          {categorized.today.length ? (
            renderTaskList(categorized.today)
          ) : (
            <p className="text-sm text-gray-500">No tasks due today.</p>
          )}
        </Card>
        <Card title="This Week" className="space-y-3">
          {categorized.thisWeek.length ? (
            renderTaskList(categorized.thisWeek)
          ) : (
            <p className="text-sm text-gray-500">No tasks due this week.</p>
          )}
        </Card>
        <Card title="Later" className="space-y-3">
          {categorized.later.length ? (
            renderTaskList(categorized.later)
          ) : (
            <p className="text-sm text-gray-500">No tasks scheduled for later.</p>
          )}
        </Card>
        <Card title="Completed" className="space-y-3">
          {categorized.done.length ? (
            renderTaskList(categorized.done)
          ) : (
            <p className="text-sm text-gray-500">No tasks completed yet.</p>
          )}
        </Card>
      </div>
    </div>
  );
}