"use client";

import { useState } from 'react';
import { useData } from '../context';
import Card from '../../components/Card';

export default function SettingsPage() {
  const {
    money,
    setMoney,
    house,
    setHouse,
    tasks,
    setTasks,
    opportunities,
    setOpportunities,
    trading,
    setTrading,
    automationSettings,
    setAutomationSettings,
    lastUpdated,
  } = useData();
  const [showVerse, setShowVerse] = useState(() => {
    if (typeof window === 'undefined') return true;
    const val = localStorage.getItem('showVerse');
    return val !== 'false';
  });

  const updateIncomeBudget = (index: number, budget: number) => {
    const incomes = money.incomes.slice();
    incomes[index] = { ...incomes[index], budget };
    setMoney({ ...money, incomes });
  };

  const resetData = () => {
    localStorage.clear();
    window.location.reload();
  };

  const toggleVerse = () => {
    const newValue = !showVerse;
    setShowVerse(newValue);
    if (typeof window !== 'undefined') {
      localStorage.setItem('showVerse', String(newValue));
    }
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Settings</h1>
      <p className="text-sm text-gray-500">Adjust your budgets, preferences and reset your data. Changes are saved automatically.</p>
      <Card title="Monthly Income Budgets" className="space-y-4">
        <p className="text-xs text-gray-500">Update the expected monthly income for each earner. This feeds into your budget calculations.</p>
        {money.incomes.map((income, idx) => (
          <div key={idx} className="flex items-center gap-4">
            <span className="w-24 font-medium">{income.name}</span>
            <input
              type="number"
              value={income.budget}
              onChange={(e) => updateIncomeBudget(idx, parseFloat(e.target.value) || 0)}
              className="flex-1 bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
            />
          </div>
        ))}
      </Card>
      <Card title="Preferences" className="space-y-4">
        <div className="flex items-center gap-3">
          <input type="checkbox" id="verse-toggle" checked={showVerse} onChange={toggleVerse} />
          <label htmlFor="verse-toggle" className="text-sm">Show verse of the day on the Home page</label>
        </div>
      </Card>
      <Card title="Danger Zone" className="space-y-4">
        <p className="text-xs text-red-600">Resetting will erase all of your data from this device and reload default values.</p>
        <button
          className="px-4 py-2 bg-red-500 text-white text-sm rounded-md hover:bg-red-600"
          onClick={resetData}
        >
          Reset All Data
        </button>
      </Card>

      {/* Automation settings */}
      <Card title="Automation & Notifications" className="space-y-4">
        <p className="text-xs text-gray-500">Control how Life OS runs in the background and how it notifies you of important changes.</p>
        <div className="flex flex-col gap-3">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={automationSettings.dailyEnabled}
              onChange={(e) => setAutomationSettings({ ...automationSettings, dailyEnabled: e.target.checked })}
            />
            <span className="text-sm">Daily automation (generate daily brief & notifications)</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={automationSettings.periodicEnabled}
              onChange={(e) => setAutomationSettings({ ...automationSettings, periodicEnabled: e.target.checked })}
            />
            <span className="text-sm">Periodic updates (refresh data regularly)</span>
          </label>
          {automationSettings.periodicEnabled && (
            <div className="flex items-center gap-2 ml-4">
              <label className="text-xs" htmlFor="interval">Refresh every (minutes):</label>
              <input
                id="interval"
                type="number"
                min={5}
                max={240}
                step={5}
                value={automationSettings.periodicInterval}
                onChange={(e) => setAutomationSettings({ ...automationSettings, periodicInterval: parseInt(e.target.value) || 60 })}
                className="w-20 bg-transparent border-b border-gray-300 dark:border-gray-600 text-sm focus:outline-none"
              />
            </div>
          )}
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={automationSettings.notificationsEnabled}
              onChange={(e) => setAutomationSettings({ ...automationSettings, notificationsEnabled: e.target.checked })}
            />
            <span className="text-sm">Enable notifications</span>
          </label>
        </div>
        <div className="mt-2">
          <p className="text-xs text-gray-500">Last daily brief: {lastUpdated.dailyBrief ? new Date(lastUpdated.dailyBrief).toLocaleString() : 'Never'}</p>
          <p className="text-xs text-gray-500">Last data refresh: {lastUpdated.market || lastUpdated.calendar || lastUpdated.verse || lastUpdated.weather ? new Date(lastUpdated.market || lastUpdated.calendar || lastUpdated.verse || lastUpdated.weather as string).toLocaleString() : 'Never'}</p>
        </div>
      </Card>
      <p className="text-xs text-gray-500 italic">
        All settings and data are stored locally on this device. You can adjust preferences at any time.
      </p>
    </div>
  );
}