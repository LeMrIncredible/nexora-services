"use client";

import { useState } from 'react';
import { useData } from '../context';
import Card from '../../components/Card';
import ProgressBar from '../../components/ProgressBar';

export default function HousePage() {
  const { house, setHouse } = useData();
  // Temporary form for adding a milestone
  const [milestone, setMilestone] = useState({ item: '', chosenCost: 0, currentTotal: 0, notes: '' });

  const addMilestone = () => {
    if (!milestone.item) return;
    setHouse({ ...house, milestones: [...house.milestones, milestone] });
    setMilestone({ item: '', chosenCost: 0, currentTotal: 0, notes: '' });
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">House Plan</h1>

      {/* Overall progress and next best step side by side on larger screens */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Overall Progress" className="space-y-3">
          <p className="text-sm">Current stage: <span className="font-medium">{house.stage}</span></p>
          <ProgressBar value={house.progress} label={`${(house.progress * 100).toFixed(1)}% complete`} />
          <p className="text-sm">
            ${house.current.toLocaleString(undefined, { maximumFractionDigits: 2 })} / ${house.target.toLocaleString(undefined, { maximumFractionDigits: 2 })} saved
          </p>
        </Card>
        <Card title="Next Best Step" className="space-y-3">
          <p className="text-sm whitespace-pre-line">
            {house.nextSteps || 'No next step defined. Add one in Settings.'}
          </p>
          {house.blockers && (
            <div className="mt-2 p-3 rounded-md bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-300 dark:border-yellow-600">
              <p className="text-xs font-semibold text-yellow-700 dark:text-yellow-400">Blockers</p>
              <p className="text-xs whitespace-pre-line text-yellow-700 dark:text-yellow-400">{house.blockers}</p>
            </div>
          )}
        </Card>
      </div>

      {/* Milestones with progress bars */}
      <Card title="Milestones" className="space-y-4">
        {house.milestones.length > 0 ? (
          <div className="space-y-4">
            {house.milestones.map((m, idx) => {
              const max = m.chosenCost || 0;
              const current = m.currentTotal || 0;
              const progress = max > 0 ? current / max : 0;
              return (
                <div key={idx} className="space-y-2 border-b border-gray-200 dark:border-gray-700 pb-3 last:border-none">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <p className="font-semibold">{m.item}</p>
                      {m.notes && <p className="text-xs text-gray-500 dark:text-gray-400">{m.notes}</p>}
                    </div>
                    <div className="text-right min-w-[120px]">
                      <p className="text-sm">Cost: {max ? `$${max.toLocaleString()}` : '-'}</p>
                      <p className="text-sm">Spent: {current ? `$${current.toLocaleString()}` : '-'}</p>
                    </div>
                  </div>
                  <ProgressBar value={progress} label={max ? `${Math.round(progress * 100)}%` : undefined} />
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-sm text-gray-500">No milestones defined yet.</p>
        )}

        {/* Form to add a new milestone */}
        <div className="pt-4 border-t border-gray-200 dark:border-gray-700 space-y-3">
          <h4 className="text-sm font-semibold">Add Milestone</h4>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <input
              type="text"
              placeholder="Milestone"
              value={milestone.item}
              onChange={(e) => setMilestone({ ...milestone, item: e.target.value })}
              className="md:col-span-2 bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
            />
            <input
              type="number"
              placeholder="Cost"
              value={milestone.chosenCost}
              onChange={(e) => setMilestone({ ...milestone, chosenCost: parseFloat(e.target.value) || 0 })}
              className="bg-transparent border-b border-gray-300 dark:border-gray-600 text-right focus:outline-none focus:border-primary py-1"
            />
            <input
              type="number"
              placeholder="Spent"
              value={milestone.currentTotal}
              onChange={(e) => setMilestone({ ...milestone, currentTotal: parseFloat(e.target.value) || 0 })}
              className="bg-transparent border-b border-gray-300 dark:border-gray-600 text-right focus:outline-none focus:border-primary py-1"
            />
            <input
              type="text"
              placeholder="Notes"
              value={milestone.notes}
              onChange={(e) => setMilestone({ ...milestone, notes: e.target.value })}
              className="md:col-span-2 bg-transparent border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:border-primary py-1"
            />
            <button
              className="px-4 py-2 bg-primary text-white text-sm rounded-md hover:bg-primary-dark"
              onClick={addMilestone}
            >
              Add
            </button>
          </div>
        </div>
      </Card>

      {/* Timeline section */}
      <Card title="Timeline" className="space-y-4">
        {house.timeline.length > 0 ? (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left py-2">Phase</th>
                <th className="text-left py-2">Target Date</th>
                <th className="text-left py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {house.timeline.map((t, idx) => (
                <tr key={idx} className="border-b border-gray-100 dark:border-gray-800">
                  <td className="py-1">{t.name}</td>
                  <td className="py-1">{new Date(t.targetDate).toLocaleDateString()}</td>
                  <td className="py-1 capitalize">{t.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="text-sm text-gray-500">No timeline defined.</p>
        )}
      </Card>
    </div>
  );
}