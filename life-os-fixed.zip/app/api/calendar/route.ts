import { NextRequest, NextResponse } from 'next/server';
import { calendarSeed } from '../../../utils/seedData';

/**
 * API route for fetching upcoming calendar events. This handler attempts
 * to use Google Calendar if OAuth credentials are configured. If the
 * necessary environment variables or tokens are missing, it returns
 * seeded events instead. In a production application, you would
 * implement the OAuth flow and token storage here.
 */
export async function GET(req: NextRequest) {
  try {
    // Determine if a client ID or API key has been supplied
    const url = new URL(req.url);
    const apiKey = url.searchParams.get('key') || undefined;
    const clientId = url.searchParams.get('clientId') || process.env.GOOGLE_CLIENT_ID;
    const clientSecret = url.searchParams.get('clientSecret') || process.env.GOOGLE_CLIENT_SECRET;
    // TODO: implement OAuth token exchange and API calls when clientId/clientSecret are provided.
    // Currently this endpoint does not perform a real Google Calendar call. If an API
    // key is provided, you could use Google Calendar's public feed API, but most
    // calendars require OAuth. Until full OAuth is implemented, return seeded
    // events.
    return NextResponse.json({ events: calendarSeed });
  } catch (err) {
    console.error('Calendar route error', err);
    return NextResponse.json({ error: 'Unexpected error' }, { status: 500 });
  }
}