import { NextRequest, NextResponse } from 'next/server';
import { fetchCalendarEventsWithToken } from '../../../../utils/services/google';

/**
 * Server API endpoint for retrieving calendar events from Google. It
 * expects a POST request with a JSON body containing a `tokens`
 * property (OAuth tokens) and an optional `daysAhead` integer to
 * control how far in the future to fetch events. The response
 * includes an array of events or an error message.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { tokens, daysAhead } = body;
    if (!tokens) {
      return NextResponse.json({ error: 'Missing tokens' }, { status: 400 });
    }
    const events = await fetchCalendarEventsWithToken(tokens, daysAhead || 7);
    return NextResponse.json({ events });
  } catch (err) {
    console.error('Google calendar API route error', err);
    return NextResponse.json({ error: 'Failed to fetch calendar events' }, { status: 500 });
  }
}