import { NextRequest, NextResponse } from 'next/server';
import { getTokensFromCode } from '../../../../utils/services/google';

/**
 * OAuth callback endpoint. After the user authorises the application,
 * Google redirects back to this URL with a `code` parameter. This handler
 * exchanges the code for access and refresh tokens and returns them to
 * the client. In a production environment you might persist tokens
 * server‑side or issue a session. For simplicity the tokens are
 * returned in the response so the client can store them locally.
 */
export async function GET(req: NextRequest) {
  try {
    const url = req.nextUrl;
    const code = url.searchParams.get('code');
    const redirectUri = url.searchParams.get('redirectUri') || undefined;
    if (!code) {
      return NextResponse.json({ error: 'Missing authorisation code' }, { status: 400 });
    }
    const tokens = await getTokensFromCode(code, redirectUri);
    return NextResponse.json({ tokens });
  } catch (err) {
    console.error('Google OAuth callback error', err);
    return NextResponse.json({ error: 'Failed to exchange code' }, { status: 500 });
  }
}