import { NextRequest, NextResponse } from 'next/server';
import { fetchSheetValuesWithToken } from '../../../../utils/services/google';

/**
 * Server API endpoint for reading values from a Google Spreadsheet. It
 * expects a POST request with a JSON body containing `tokens`,
 * `sheetId` and optionally a `range` in A1 notation. When successful
 * it returns an array of rows (string[][]). If sheetId or tokens are
 * missing the request is rejected. Errors from the Google API are
 * caught and returned with a 500 status.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { tokens, sheetId, range } = body;
    if (!tokens || !sheetId) {
      return NextResponse.json({ error: 'Missing tokens or sheetId' }, { status: 400 });
    }
    const values = await fetchSheetValuesWithToken(tokens, sheetId, range);
    return NextResponse.json({ values });
  } catch (err) {
    console.error('Google sheets API route error', err);
    return NextResponse.json({ error: 'Failed to fetch sheet values' }, { status: 500 });
  }
}