import { NextRequest, NextResponse } from 'next/server';
import { generateGoogleAuthUrl } from '../../../../utils/services/google';

/**
 * This endpoint generates a Google OAuth URL for the client to initiate
 * authentication. It accepts an optional 'redirectUri' query param to
 * override the default redirect. The scopes requested grant read-only
 * access to calendar events and spreadsheets.
 */
export async function GET(req: NextRequest) {
  const url = req.nextUrl;
  const redirectUri = url.searchParams.get('redirectUri') || undefined;
  // Define the scopes required for Calendar and Sheets read-only access
  const scopes = [
    'https://www.googleapis.com/auth/calendar.readonly',
    'https://www.googleapis.com/auth/spreadsheets.readonly',
  ];
  try {
    const authUrl = generateGoogleAuthUrl(scopes, redirectUri);
    return NextResponse.json({ url: authUrl });
  } catch (err) {
    console.error('Failed to generate Google auth URL', err);
    return NextResponse.json({ error: 'Unable to generate auth URL' }, { status: 500 });
  }
}