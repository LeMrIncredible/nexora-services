import { NextRequest, NextResponse } from 'next/server';
import { generateChatReply } from '../../../utils/services/chat';

/**
 * API route handler for the in‑app assistant. This endpoint accepts a POST
 * request containing a `prompt` string and a `context` object describing
 * the user’s current Life OS state. It attempts to use the OpenAI API
 * (via the `OPENAI_API_KEY` environment variable) to generate a response.
 * If no key is provided or the request fails, it falls back to the
 * built‑in rule‑based reply engine.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { prompt, context, apiKey } = body as {
      prompt: string;
      context: {
        money: any;
        house: any;
        tasks: any[];
        opportunities: any[];
        trading: any[];
        calendarEvents: any[];
      };
      apiKey?: string;
    };
    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json({ error: 'Invalid prompt' }, { status: 400 });
    }
    // Attempt to call OpenAI if an API key is configured
    const envKey = process.env.OPENAI_API_KEY;
    const effectiveKey = apiKey || envKey;
    if (effectiveKey) {
      try {
        const systemPrompt = `You are Life OS, a personal operating system assistant. You have access to the user’s financial, task, house plan, opportunities, trading and calendar data. Always provide concise, actionable guidance and use the provided context to ground your responses. When appropriate, summarise key information (e.g. top tasks, financial status, next house step, best opportunity, upcoming events, watchlist) and suggest next actions. Do not invent data.`;
        const messages = [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: prompt },
        ];
        // Send a chat completion request to OpenAI
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          Authorization: `Bearer ${effectiveKey}`,
          },
          body: JSON.stringify({
            model: 'gpt-3.5-turbo',
            messages,
            max_tokens: 256,
            temperature: 0.7,
          }),
        });
        if (response.ok) {
          const data = await response.json();
          const content = data.choices?.[0]?.message?.content?.trim();
          if (content) {
            return NextResponse.json({ reply: content });
          }
        }
        // If the API request failed or returned no content, fall back
      } catch (err) {
        console.error('OpenAI API call failed', err);
        // Continue to fallback
      }
    }
    // Use the rule‑based reply engine as a fallback
    const reply = generateChatReply(prompt, context);
    return NextResponse.json({ reply, fallback: true });
  } catch (err) {
    console.error('Assistant route error', err);
    return NextResponse.json({ error: 'Unexpected error' }, { status: 500 });
  }
}