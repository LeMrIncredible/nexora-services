import { NextRequest, NextResponse } from 'next/server';
import { marketSeed } from '../../../utils/seedData';

/**
 * API route for fetching live market quotes. Given a list of symbols
 * provided via the query parameter `symbols` (comma‑separated), this
 * endpoint attempts to call an external market data API using the
 * `MARKET_API_KEY` environment variable. If the key is missing or the
 * request fails, it falls back to seeded data. To minimise external
 * requests, the implementation only attempts a fetch when a valid
 * environment variable and symbol list are present.
 */
export async function GET(req: NextRequest) {
  try {
    // Use API key from query parameter if provided; fall back to environment
    const url = new URL(req.url);
    const queryKey = url.searchParams.get('key') || undefined;
    const apiKey = queryKey || process.env.MARKET_API_KEY;
    // Extract comma‑separated symbols from query string, if provided
    const symbolsParam = url.searchParams.get('symbols');
    const symbols = symbolsParam ? symbolsParam.split(',').map((s) => s.trim().toUpperCase()) : [];
    if (apiKey && symbols.length > 0) {
      try {
        // Example using Alpha Vantage free API. For multiple symbols you would
        // need to perform individual requests or use a batch endpoint from
        // another provider. Here we demonstrate a single symbol fetch.
        const results: any[] = [];
        for (const symbol of symbols) {
          const resp = await fetch(
            `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${encodeURIComponent(symbol)}&apikey=${apiKey}`
          );
          if (resp.ok) {
            const data = await resp.json();
            const quote = data['Global Quote'];
            if (quote) {
              results.push({
                symbol,
                price: parseFloat(quote['05. price']),
                change: parseFloat(quote['09. change']),
                updatedAt: new Date().toISOString(),
              });
            }
          }
        }
        if (results.length > 0) {
          return NextResponse.json({ quotes: results });
        }
      } catch (err) {
        console.error('Market API call failed', err);
      }
    }
    // Fallback to seeded data. Filter seeds if symbols requested
    let quotes = marketSeed;
    if (symbols.length > 0) {
      quotes = marketSeed.filter((q) => symbols.includes(q.symbol.toUpperCase()));
    }
    return NextResponse.json({ quotes });
  } catch (err) {
    console.error('Market route error', err);
    return NextResponse.json({ error: 'Unexpected error' }, { status: 500 });
  }
}