import { NextRequest, NextResponse } from 'next/server';

/**
 * API route for fetching current weather conditions. If a weather API
 * key is configured via WEATHER_API_KEY, it attempts to call the
 * OpenWeatherMap API for Bangor, Maine (or another location if
 * specified via the `city` query parameter). When the API call fails
 * or no key is present, it returns static weather data representative
 * of a typical day in Bangor.
 */
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const queryKey = url.searchParams.get('key') || undefined;
    const apiKey = queryKey || process.env.WEATHER_API_KEY;
    const city = url.searchParams.get('city') || 'Bangor';
    if (apiKey) {
      try {
        // Call OpenWeatherMap current weather API
        const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&units=imperial&appid=${apiKey}`;
        const resp = await fetch(apiUrl);
        if (resp.ok) {
          const data = await resp.json();
          const temp = data.main?.temp;
          const condition = data.weather?.[0]?.description;
          if (temp && condition) {
            return NextResponse.json({ weather: { temp, condition, location: city } });
          }
        }
      } catch (err) {
        console.error('Weather API call failed', err);
      }
    }
    // Fallback static weather
    return NextResponse.json({ weather: { temp: 68, condition: 'Partly cloudy', location: 'Bangor' } });
  } catch (err) {
    console.error('Weather route error', err);
    return NextResponse.json({ error: 'Unexpected error' }, { status: 500 });
  }
}