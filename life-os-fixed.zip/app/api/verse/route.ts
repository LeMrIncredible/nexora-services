import { NextRequest, NextResponse } from 'next/server';

// Fallback verses used when an external verse API is unavailable. These
// mirror the static list from utils/services/verse.ts.
const fallbackVerses = [
  {
    reference: 'Proverbs 3:5-6',
    text: 'Trust in the Lord with all your heart and lean not on your own understanding; in all your ways submit to him, and he will make your paths straight.',
  },
  {
    reference: 'Philippians 4:6',
    text: 'Do not be anxious about anything, but in every situation, by prayer and petition, with thanksgiving, present your requests to God.',
  },
  {
    reference: 'Jeremiah 29:11',
    text: 'For I know the plans I have for you, declares the Lord, plans to prosper you and not to harm you, plans to give you hope and a future.',
  },
];

/**
 * API route to retrieve the verse of the day. This attempts to fetch
 * from a configurable external endpoint defined by the VERSE_API_SOURCE
 * environment variable. If the request fails or no endpoint is set,
 * it returns a verse from the fallback list based on the current date.
 */
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const querySource = url.searchParams.get('source');
    const source = querySource || process.env.VERSE_API_SOURCE;
    if (source) {
      try {
        const resp = await fetch(source);
        if (resp.ok) {
          const data = await resp.json();
          // Attempt to normalise a few common response shapes
          if (data.verse) {
            return NextResponse.json({ verse: data.verse });
          }
          if (data.text && data.reference) {
            return NextResponse.json({ verse: { text: data.text, reference: data.reference } });
          }
        }
      } catch (err) {
        console.error('Verse API call failed', err);
      }
    }
    // Pick a fallback verse based on the day of the month
    const index = new Date().getDate() % fallbackVerses.length;
    return NextResponse.json({ verse: fallbackVerses[index] });
  } catch (err) {
    console.error('Verse route error', err);
    return NextResponse.json({ error: 'Unexpected error' }, { status: 500 });
  }
}