import { ConnectionsData, MarketQuote } from '../../types';
import { marketSeed } from '../seedData';

/**
 * Fetch live market quotes. If the market integration is enabled and a key
 * exists, this would call an external market data API to refresh quotes.
 * This implementation returns seeded data by default.
 */
/**
 * Fetch live market quotes via the server API. When the market integration
 * is enabled, this function calls the `/api/market` endpoint with any
 * provided symbols. If the request fails or the integration is disabled,
 * it falls back to seeded data. Symbols should be provided as an array
 * of tickers (e.g. ['AAPL', 'TSLA']).
 */
export async function fetchMarketQuotes(
  connections: ConnectionsData,
  symbols: string[] = []
): Promise<MarketQuote[]> {
  if (typeof window !== 'undefined' && connections.market?.enabled) {
    try {
      // Construct query string when symbols are supplied
      const key = connections.market.key || '';
      const params = new URLSearchParams();
      if (symbols.length > 0) params.append('symbols', symbols.join(','));
      if (key) params.append('key', key);
      const query = params.toString() ? `?${params.toString()}` : '';
      const res = await fetch(`/api/market${query}`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.quotes)) return data.quotes as MarketQuote[];
      }
    } catch (err) {
      console.error('Failed to fetch market data', err);
    }
  }
  // Fall back to seed data; optionally filter by symbols
  if (symbols.length > 0) {
    return marketSeed.filter((q) => symbols.includes(q.symbol.toUpperCase()));
  }
  return marketSeed;
}