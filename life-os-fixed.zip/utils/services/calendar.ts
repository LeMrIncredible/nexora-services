import { ConnectionsData, CalendarEvent } from '../../types';
import { calendarSeed } from '../seedData';

/**
 * Fetch upcoming calendar events. When the calendar integration is enabled,
 * this would call the Google Calendar API and return events within the next
 * few days. Since OAuth is out of scope, this function returns the seeded
 * events by default. The daysAhead parameter is reserved for future use to
 * limit the range of events retrieved.
 */
export async function fetchCalendarEvents(
  connections: ConnectionsData,
  daysAhead = 7
): Promise<CalendarEvent[]> {
  // When the calendar integration is enabled and tokens exist, call the
  // Google Calendar API via our server route. This uses OAuth tokens stored
  // in the calendar or sheet credential. If tokens are missing, it
  // falls back to the default /api/calendar endpoint which returns
  // seeded events. If all fails, seeded events are returned.
  if (typeof window !== 'undefined' && connections.calendar?.enabled) {
    try {
      const tokens = connections.calendar.tokens || connections.sheet?.tokens;
      if (tokens) {
        const res = await fetch('/api/google/calendar', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tokens, daysAhead }),
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.events)) return data.events as CalendarEvent[];
        }
      }
      // Fallback to default calendar endpoint (seeded events)
      const res = await fetch('/api/calendar');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.events)) return data.events as CalendarEvent[];
      }
    } catch (err) {
      console.error('Failed to fetch calendar events', err);
    }
  }
  // Return seeded events by default
  return calendarSeed;
}