import { google } from 'googleapis';

/**
 * Initialise an OAuth2 client using environment variables. The redirect
 * URI must match the one registered in your Google Cloud console. When
 * calling on the server, process.env values are used; when calling on
 * the client, you must pass a redirect URI explicitly.
 */
export function getOAuthClient(redirectUri?: string) {
  const client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    redirectUri || process.env.NEXT_PUBLIC_GOOGLE_REDIRECT_URI,
  );
  return client;
}

/**
 * Generate the Google OAuth URL for the given scopes. The returned URL
 * should be presented to the user to begin the authentication flow.
 */
export function generateGoogleAuthUrl(scopes: string[], redirectUri?: string) {
  const client = getOAuthClient(redirectUri);
  const url = client.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: scopes,
  });
  return url;
}

/**
 * Exchange an authorization code for an access and refresh token. This
 * function runs on the server; do not call it from the client. Tokens
 * should be stored securely and refreshed when expired.
 */
export async function getTokensFromCode(code: string, redirectUri?: string) {
  const client = getOAuthClient(redirectUri);
  const { tokens } = await client.getToken(code);
  return tokens;
}

/**
 * Fetch the next N days of calendar events using an access token. This
 * function runs on the server. It returns a simple structure with
 * id, title, start, end and location for each event. It fetches events
 * from the primary calendar by default.
 */
export async function fetchCalendarEventsWithToken(tokens: any, daysAhead = 1) {
  const client = getOAuthClient();
  client.setCredentials(tokens);
  const calendar = google.calendar({ version: 'v3', auth: client });
  const now = new Date();
  const timeMin = now.toISOString();
  const timeMax = new Date(now.getTime() + daysAhead * 24 * 60 * 60 * 1000).toISOString();
  const res = await calendar.events.list({
    calendarId: 'primary',
    timeMin,
    timeMax,
    singleEvents: true,
    orderBy: 'startTime',
  });
  const items = res.data.items || [];
  return items.map((ev: any) => ({
    id: ev.id || '',
    title: ev.summary || '(No title)',
    start: ev.start?.dateTime || ev.start?.date,
    end: ev.end?.dateTime || ev.end?.date,
    location: ev.location || '',
    description: ev.description || '',
  }));
}

/**
 * Fetch values from a Google Sheet using an access token. sheetId refers
 * to the spreadsheet ID (the part after /d/ in the URL). range is an
 * optional A1 notation range (e.g. 'Sheet1!A1:C100'). If omitted, the
 * API will attempt to return all values. Returns an array of rows.
 */
export async function fetchSheetValuesWithToken(tokens: any, sheetId: string, range?: string) {
  const client = getOAuthClient();
  client.setCredentials(tokens);
  const sheets = google.sheets({ version: 'v4', auth: client });
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: sheetId,
    range: range || '',
  });
  return res.data.values as string[][];
}

/**
 * Simple helper to extract a spreadsheet ID from a Google Sheets URL. If
 * the input is already an ID, it is returned unchanged. Otherwise it
 * attempts to parse the portion between `/d/` and the following `/`.
 */
export function extractSheetId(input: string): string | null {
  if (!input.includes('https')) {
    return input.trim();
  }
  try {
    const match = input.match(/\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
  } catch (err) {
    return null;
  }
}