// NOTE: The original implementation of these Google integration helpers used the
// `googleapis` library, which depends on Node built‑in modules like `http2`
// and `net`. When bundling a Next.js app for static export, those modules are
// unavailable in the browser environment, causing build errors. To avoid
// pulling in heavy dependencies and to ensure the site builds successfully,
// we provide lightweight stub implementations instead. These helpers return
// benign defaults or throw descriptive errors when invoked. If you wish to
// enable Google OAuth and API access, implement these functions on the server
// and call them via API routes instead of importing them into client code.

// We intentionally omit importing `googleapis` here to prevent bundler
// attempting to resolve Node‑only modules.

/**
 * Initialise an OAuth2 client using environment variables. The redirect
 * URI must match the one registered in your Google Cloud console. When
 * calling on the server, process.env values are used; when calling on
 * the client, you must pass a redirect URI explicitly.
 */
export function getOAuthClient(redirectUri?: string) {
  // Stub: return `null` as we cannot construct a real OAuth client without
  // server‑side dependencies. This function should only be used on the
  // server; if called in the browser, it will return null.
  console.warn('getOAuthClient was called in the browser. Google OAuth is disabled.');
  return null;
}

/**
 * Generate the Google OAuth URL for the given scopes. The returned URL
 * should be presented to the user to begin the authentication flow.
 */
export function generateGoogleAuthUrl(scopes: string[], redirectUri?: string) {
  // Stub: return an empty string since we cannot generate a real auth URL
  // without server‑side Google OAuth. Applications should handle this case
  // gracefully by disabling login buttons when Google integration is not
  // configured.
  console.warn('generateGoogleAuthUrl was called in the browser. Google OAuth is disabled.');
  return '';
}

/**
 * Exchange an authorization code for an access and refresh token. This
 * function runs on the server; do not call it from the client. Tokens
 * should be stored securely and refreshed when expired.
 */
export async function getTokensFromCode(code: string, redirectUri?: string) {
  // Stub: reject with an error explaining that token exchange must occur on the
  // server. A client application should call a server API endpoint to handle
  // Google OAuth callbacks.
  throw new Error('getTokensFromCode cannot be executed in the browser. Use a server route instead.');
}

/**
 * Fetch the next N days of calendar events using an access token. This
 * function runs on the server. It returns a simple structure with
 * id, title, start, end and location for each event. It fetches events
 * from the primary calendar by default.
 */
export async function fetchCalendarEventsWithToken(tokens: any, daysAhead = 1) {
  // Stub: return an empty array. When Google integration is disabled, fall back
  // to seeded calendar events using `fetchCalendarEvents` from
  // `utils/services/calendar.ts` instead.
  console.warn('fetchCalendarEventsWithToken was called without Google API support. Returning empty list.');
  return [];
}

/**
 * Fetch values from a Google Sheet using an access token. sheetId refers
 * to the spreadsheet ID (the part after /d/ in the URL). range is an
 * optional A1 notation range (e.g. 'Sheet1!A1:C100'). If omitted, the
 * API will attempt to return all values. Returns an array of rows.
 */
export async function fetchSheetValuesWithToken(tokens: any, sheetId: string, range?: string) {
  // Stub: return an empty array. Without Google API access, sheet values cannot
  // be retrieved. Applications should handle this case by showing a
  // placeholder or error message.
  console.warn('fetchSheetValuesWithToken was called without Google API support. Returning empty array.');
  return [] as string[][];
}

/**
 * Simple helper to extract a spreadsheet ID from a Google Sheets URL. If
 * the input is already an ID, it is returned unchanged. Otherwise it
 * attempts to parse the portion between `/d/` and the following `/`.
 */
export function extractSheetId(input: string): string | null {
  if (!input.includes('https')) {
    return input.trim();
  }
  try {
    const match = input.match(/\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
  } catch (err) {
    return null;
  }
}