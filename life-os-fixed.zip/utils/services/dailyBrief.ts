import { MoneyData, Task, Opportunity, HousePlanData, CalendarEvent, DailyBrief } from '../../types';

/**
 * Generate a daily brief summarising the user’s current situation. This
 * function inspects finances, tasks, opportunities, house plan and
 * calendar events to assemble a concise summary. It does not access
 * external services; instead it relies on data already loaded into the
 * application. The caller is responsible for persisting the result.
 */
export function generateDailyBrief(
  money: MoneyData,
  tasks: Task[],
  opportunities: Opportunity[],
  house: HousePlanData,
  calendarEvents: CalendarEvent[],
): DailyBrief {
  const now = new Date();
  const id = now.toISOString();
  // Financial summary: overspending or safe to spend
  const overspend = money.weeklySpending - money.weeklyBudget;
  const financialSummary = overspend > 0
    ? `Overspending by $${overspend.toFixed(2)} this week. Safe to spend: $${money.safeToSpend.toFixed(2)}.`
    : `On track. Safe to spend: $${money.safeToSpend.toFixed(2)}.`;
  // Top 3 tasks by priority and due date
  const priorityOrder: Record<string, number> = { high: 1, medium: 2, low: 3 };
  const sortedTasks = [...tasks]
    .filter((t) => t.status !== 'done')
    .sort((a, b) => {
      const pa = priorityOrder[a.priority];
      const pb = priorityOrder[b.priority];
      if (pa !== pb) return pa - pb;
      if (a.dueDate && b.dueDate) return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      return 0;
    })
    .slice(0, 3)
    .map((t) => ({ title: t.title, dueDate: t.dueDate }));
  // Determine best opportunity based on value * urgency / effort
  let bestOpportunity: { title: string; value: number } | undefined = undefined;
  if (opportunities.length > 0) {
    const sortedOpp = [...opportunities]
      .filter((o) => o.status !== 'done')
      .sort((a, b) => ((b.estimatedValue * b.urgency) / b.effort) - ((a.estimatedValue * a.urgency) / a.effort));
    const top = sortedOpp[0];
    if (top) bestOpportunity = { title: top.title, value: top.estimatedValue };
  }
  // Determine risk: overspending or no tasks or no opportunity etc.
  let risk: string | undefined;
  if (overspend > 0) {
    risk = `You are overspending by $${overspend.toFixed(2)}.`;
  } else if (sortedTasks.length === 0) {
    risk = 'You have no high‑priority tasks today.';
  } else if (!bestOpportunity) {
    risk = 'No active opportunities at the moment.';
  }
  // Today's events (up to 3)
  const todayStr = now.toDateString();
  const todaysEvents = calendarEvents
    .filter((ev) => new Date(ev.start).toDateString() === todayStr)
    .slice(0, 3)
    .map((ev) => ({ title: ev.title, time: new Date(ev.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }));
  // Focus message: summarise the primary area of attention
  let focus: string;
  if (overspend > 0) {
    focus = 'Watch your spending and cut discretionary costs today.';
  } else if (sortedTasks.length > 0) {
    focus = `Focus on your top task: ${sortedTasks[0].title}.`;
  } else if (bestOpportunity) {
    focus = `Consider your best opportunity: ${bestOpportunity.title}.`;
  } else {
    focus = 'Review your plan and identify new priorities.';
  }
  return {
    id,
    createdAt: id,
    focus,
    financialSummary,
    topTasks: sortedTasks,
    bestOpportunity,
    risk,
    events: todaysEvents,
  };
}