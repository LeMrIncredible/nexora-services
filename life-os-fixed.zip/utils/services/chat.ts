import {
  MoneyData,
  HousePlanData,
  Task,
  Opportunity,
  TradingIdea,
  CalendarEvent,
} from '../../types';

/**
 * Generate a reply to a user message based on the current Life OS context. This
 * is a simple rule-based engine intended to provide useful responses without
 * relying on an external LLM. It looks for keywords in the user's message
 * and surfaces relevant information from the app's state. For more advanced
 * behaviour, replace this with calls to a language model using the OpenAI
 * integration when available.
 */
export function generateChatReply(
  message: string,
  {
    money,
    house,
    tasks,
    opportunities,
    trading,
    calendarEvents,
  }: {
    money: MoneyData;
    house: HousePlanData;
    tasks: Task[];
    opportunities: Opportunity[];
    trading: TradingIdea[];
    calendarEvents: CalendarEvent[];
  }
) {
  const text = message.toLowerCase();

  // Helper to compute overspending for the week
  const overspending = money.weeklySpending - money.weeklyBudget;

  // Upcoming events today
  const today = new Date().toDateString();
  const todaysEvents = calendarEvents.filter(
    (ev) => new Date(ev.start).toDateString() === today
  );

  // Determine top task
  const priorityOrder: Record<string, number> = { high: 1, medium: 2, low: 3 };
  const topTask = [...tasks]
    .filter((t) => t.status !== 'done')
    .sort((a, b) => {
      const pa = priorityOrder[a.priority];
      const pb = priorityOrder[b.priority];
      if (pa !== pb) return pa - pb;
      if (a.dueDate && b.dueDate) return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      return 0;
    })[0];

  // Best opportunity
  const bestOpportunity = [...opportunities]
    .filter((o) => o.status !== 'done')
    .sort((a, b) => ((b.estimatedValue * b.urgency) / b.effort) - ((a.estimatedValue * a.urgency) / a.effort))[0];

  // Generate responses based on keywords
  if (/focus|priorit/i.test(text)) {
    if (topTask) {
      return `Your top task right now is: ${topTask.title}. It is due ${topTask.dueDate ? new Date(topTask.dueDate).toLocaleDateString() : 'soon'}.`;
    }
    return 'You have no pending tasks. Enjoy your free time or add new tasks!';
  }
  if (/financial|money|budget|safe/i.test(text)) {
    const safe = money.safeToSpend.toFixed(2);
    const weekly = money.weeklyBudget.toFixed(2);
    const spent = money.weeklySpending.toFixed(2);
    return overspending > 0
      ? `You are overspending by $${(overspending).toFixed(2)} this week. Try to limit discretionary expenses. Your safe-to-spend amount is $${safe}.`
      : `You are on track with your weekly budget. You've spent $${spent} out of your $${weekly} budget. Safe-to-spend: $${safe}.`;
  }
  if (/bill/i.test(text) || /due/i.test(text)) {
    const nextMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1);
    const upcoming = money.expenses
      .filter((e) => (e.budget || e.actual) > 0)
      .map((e) => ({ ...e, dueDate: nextMonth }))
      .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime())
      .slice(0, 3);
    if (upcoming.length === 0) return 'You have no upcoming bills in the near term.';
    const list = upcoming
      .map((b) => `${b.category} on ${b.dueDate.toLocaleDateString()} ($${b.actual.toFixed(2)})`)
      .join(', ');
    return `Upcoming bills: ${list}.`;
  }
  if (/house|home|build/i.test(text)) {
    return `Current house stage: ${house.stage}. Next step: ${house.nextSteps}. Saved $${house.current.toLocaleString()} of $${house.target.toLocaleString()}.`;
  }
  if (/opportunit|income|make money/.test(text)) {
    if (bestOpportunity) {
      return `Your best opportunity is ${bestOpportunity.title} with potential value $${bestOpportunity.estimatedValue.toLocaleString()}. Effort: ${bestOpportunity.effort}, urgency: ${bestOpportunity.urgency}.`;
    }
    return 'No active opportunities at the moment.';
  }
  if (/calendar|schedule|events/.test(text)) {
    if (todaysEvents.length > 0) {
      const list = todaysEvents
        .map((ev) => `${ev.title} at ${new Date(ev.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`)
        .join(', ');
      return `Today you have: ${list}.`;
    }
    return 'You have no events scheduled for today.';
  }
  if (/trading|market|stock/.test(text)) {
    if (trading.length > 0) {
      const list = trading
        .map((t) => `${t.symbol} (entry $${t.entry.toFixed(2)}, target $${t.target.toFixed(2)})`)
        .join('; ');
      return `Your watchlist includes: ${list}. Remember to manage risk.`;
    }
    return 'Your trading watchlist is empty.';
  }
  // Default generic response
  // Construct a context‑aware summary when the query does not match a specific rule.
  const summaryParts: string[] = [];
  // Top task summary
  if (topTask) {
    summaryParts.push(`Top task: ${topTask.title}${topTask.dueDate ? ` (due ${new Date(topTask.dueDate).toLocaleDateString()})` : ''}`);
  }
  // Financial summary
  if (overspending > 0) {
    summaryParts.push(`You are overspending by $${overspending.toFixed(2)} this week`);
  } else {
    summaryParts.push(`On track with your budget (spent $${money.weeklySpending.toFixed(2)} of $${money.weeklyBudget.toFixed(2)})`);
  }
  // House next step
  if (house.nextSteps) {
    summaryParts.push(`Next house step: ${house.nextSteps}`);
  }
  // Opportunity summary
  if (bestOpportunity) {
    summaryParts.push(`Best opportunity: ${bestOpportunity.title} (value $${bestOpportunity.estimatedValue.toLocaleString()})`);
  }
  // Calendar summary
  if (todaysEvents.length > 0) {
    summaryParts.push(`You have ${todaysEvents.length} event${todaysEvents.length > 1 ? 's' : ''} today`);
  }
  // Trading summary
  if (trading.length > 0) {
    summaryParts.push(`${trading.length} idea${trading.length > 1 ? 's' : ''} on your watchlist`);
  }
  const summary = summaryParts.join('. ') + '.';
  return summary || 'I’m here to help you navigate Life OS. Ask me about your tasks, finances, house plan, opportunities, trading or schedule!';
}