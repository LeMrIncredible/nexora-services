import { ConnectionsData } from '../../types';

// A small set of backup verses. Used when there is no external API key or
// when the external service fails. Expand this list as desired.
const fallbackVerses = [
  {
    reference: 'Proverbs 3:5-6',
    text: 'Trust in the Lord with all your heart and lean not on your own understanding; in all your ways submit to him, and he will make your paths straight.',
  },
  {
    reference: 'Philippians 4:6',
    text: 'Do not be anxious about anything, but in every situation, by prayer and petition, with thanksgiving, present your requests to God.',
  },
  {
    reference: 'Jeremiah 29:11',
    text: 'For I know the plans I have for you, declares the Lord, plans to prosper you and not to harm you, plans to give you hope and a future.',
  },
];

/**
 * Fetch the verse of the day. If a verse API integration is enabled and a key
 * is provided, you could call a real API here. For now this function uses a
 * static fallback list and picks a verse based on the current date. The
 * returned object includes the verse text and its reference.
 */
export async function fetchVerse(connections: ConnectionsData) {
  // When the verse integration is enabled, call the server API. This
  // endpoint will handle any configured external verse API and fall back
  // to our static verse list if necessary.
  if (typeof window !== 'undefined' && connections.verse?.enabled) {
    try {
      const key = connections.verse.key || '';
      const query = key ? `?source=${encodeURIComponent(key)}` : '';
      const res = await fetch(`/api/verse${query}`);
      if (res.ok) {
        const data = await res.json();
        if (data.verse) return data.verse;
      }
    } catch (err) {
      console.error('Failed to fetch verse from server API', err);
    }
  }
  // Default fallback when not enabled or when API fails
  const index = new Date().getDate() % fallbackVerses.length;
  return fallbackVerses[index];
}