import { ConnectionsData, EmailSummary } from '../../types';
import { emailsSeed } from '../seedData';

/**
 * Fetch recent email summaries. If the Gmail integration is enabled and
 * connected, this would normally use the Gmail API to retrieve a list of
 * unread or important emails. For now it returns seeded email summaries.
 */
export async function fetchEmails(connections: ConnectionsData): Promise<EmailSummary[]> {
  if (connections.gmail?.enabled && connections.gmail.status === 'connected') {
    try {
      // Example: call Gmail API here
      // const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=5', {...});
      // return await res.json();
    } catch (err) {
      console.error('Failed to fetch email summaries', err);
    }
  }
  return emailsSeed;
}