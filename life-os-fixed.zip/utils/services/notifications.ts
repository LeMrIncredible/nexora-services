import { MoneyData, Task, Opportunity, HousePlanData, CalendarEvent, Notification } from '../../types';

/**
 * Generate notifications based on the current state of the user’s data. This
 * function evaluates several conditions (e.g. overspending, due tasks,
 * opportunities, calendar events) and returns a list of notifications
 * summarising the most urgent items. Notifications are created with
 * unique ids and marked unread by default. The caller should merge new
 * notifications with existing ones and handle deduplication as needed.
 */
export function generateNotifications(
  money: MoneyData,
  tasks: Task[],
  opportunities: Opportunity[],
  house: HousePlanData,
  calendarEvents: CalendarEvent[],
): Notification[] {
  const now = new Date();
  const notifications: Notification[] = [];
  // Overspending alert
  const overspend = money.weeklySpending - money.weeklyBudget;
  if (overspend > 0) {
    notifications.push({
      id: `${now.getTime()}-overspend`,
      type: 'financial',
      message: `Overspending alert: You are over budget by $${overspend.toFixed(2)} this week.`,
      createdAt: now.toISOString(),
      read: false,
    });
  }
  // Task reminders: tasks due today or tomorrow
  const today = new Date();
  const tomorrow = new Date();
  tomorrow.setDate(today.getDate() + 1);
  const dueSoon = tasks.filter((t) => t.dueDate && t.status !== 'done' && new Date(t.dueDate) <= tomorrow);
  if (dueSoon.length > 0) {
    const titles = dueSoon.map((t) => t.title).join(', ');
    notifications.push({
      id: `${now.getTime()}-tasks`,
      type: 'task',
      message: `You have tasks due soon: ${titles}.`,
      createdAt: now.toISOString(),
      read: false,
    });
  }
  // High value opportunity
  const highValue = opportunities.filter((o) => o.status !== 'done').sort((a, b) => b.estimatedValue - a.estimatedValue)[0];
  if (highValue && highValue.estimatedValue > 1000) {
    notifications.push({
      id: `${now.getTime()}-opp`,
      type: 'opportunity',
      message: `High-value opportunity: ${highValue.title} (≈$${highValue.estimatedValue.toLocaleString()}).`,
      createdAt: now.toISOString(),
      read: false,
    });
  }
  // Calendar reminder: events today
  const eventsToday = calendarEvents.filter((ev) => new Date(ev.start).toDateString() === today.toDateString());
  if (eventsToday.length > 0) {
    notifications.push({
      id: `${now.getTime()}-cal`,
      type: 'calendar',
      message: `You have ${eventsToday.length} event${eventsToday.length === 1 ? '' : 's'} today.`,
      createdAt: now.toISOString(),
      read: false,
    });
  }
  // Risk: no high priority tasks or no opportunities
  const highPriority = tasks.some((t) => t.priority === 'high' && t.status !== 'done');
  if (!highPriority) {
    notifications.push({
      id: `${now.getTime()}-risk-tasks`,
      type: 'risk',
      message: 'You have no high-priority tasks at the moment.',
      createdAt: now.toISOString(),
      read: false,
    });
  }
  return notifications;
}