import { ConnectionsData } from '../../types';

/**
 * Fetch the current weather. When the weather integration is enabled and an
 * API key exists, this function would normally call a weather API. For now
 * it returns a static object representing typical weather conditions in
 * Bangor, Maine, which the user requested as their location. The returned
 * object contains temperature in Fahrenheit, a simple condition string and
 * the city name.
 */
export async function fetchWeather(connections: ConnectionsData) {
  // When the weather integration is enabled, call the server API. It will
  // attempt to use an external weather service when configured via
  // environment variables, falling back to static data if unavailable.
  if (typeof window !== 'undefined' && connections.weather?.enabled) {
    try {
      const key = connections.weather.key || '';
      const query = key ? `?key=${encodeURIComponent(key)}` : '';
      const res = await fetch(`/api/weather${query}`);
      if (res.ok) {
        const data = await res.json();
        if (data.weather) return data.weather;
      }
    } catch (err) {
      console.error('Failed to fetch weather from server API', err);
    }
  }
  // Default static weather for demonstration purposes
  return {
    temp: 68,
    condition: 'Partly cloudy',
    location: 'Bangor',
  };
}