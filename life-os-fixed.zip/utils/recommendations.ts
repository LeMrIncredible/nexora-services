import {
  MoneyData,
  HousePlanData,
  Task,
  Opportunity,
  TradingIdea,
  CalendarEvent,
  Recommendation,
} from '../types';

/**
 * Generate a set of actionable recommendations based on the current state of
 * the dashboard. Each recommendation is classified by type which can be
 * consumed by UI components to display contextually appropriate advice.
 */
export function generateRecommendations(
  money: MoneyData,
  house: HousePlanData,
  tasks: Task[],
  opportunities: Opportunity[],
  trading: TradingIdea[],
  calendar: CalendarEvent[],
): Recommendation[] {
  const recommendations: Recommendation[] = [];
  const now = new Date();
  const idBase = now.toISOString();

  // Financial summary recommendation
  const overspending = money.weeklySpending - money.weeklyBudget;
  const financialContent = overspending > 0
    ? `You're overspending by $${overspending.toFixed(2)} this week. Cut back on discretionary expenses to get back on track.`
    : `You're doing well with your budget this week. Safe‑to‑spend: $${money.safeToSpend.toFixed(2)}.`;
  recommendations.push({ id: `${idBase}-fin`, type: 'financial', content: financialContent, createdAt: now.toISOString() });

  // Focus recommendation: top tasks
  const priorityOrder: Record<string, number> = { high: 1, medium: 2, low: 3 };
  const sortedTasks = [...tasks]
    .filter((t) => t.status !== 'done')
    .sort((a, b) => {
      const pa = priorityOrder[a.priority];
      const pb = priorityOrder[b.priority];
      if (pa !== pb) return pa - pb;
      if (a.dueDate && b.dueDate) return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      return 0;
    });
  if (sortedTasks.length > 0) {
    const top3 = sortedTasks.slice(0, 3).map((t) => t.title).join(', ');
    recommendations.push({ id: `${idBase}-focus`, type: 'focus', content: `Today's focus: ${top3}.`, createdAt: now.toISOString() });
  }

  // Opportunity recommendation: best opportunity
  const bestOpportunity = [...opportunities]
    .filter((o) => o.status !== 'done')
    .sort((a, b) => ((b.estimatedValue * b.urgency) / b.effort) - ((a.estimatedValue * a.urgency) / a.effort))[0];
  if (bestOpportunity) {
    recommendations.push({ id: `${idBase}-opp`, type: 'opportunity', content: `Opportunity to pursue: ${bestOpportunity.title} – value $${bestOpportunity.estimatedValue.toLocaleString()}, effort ${bestOpportunity.effort}, urgency ${bestOpportunity.urgency}.`, createdAt: now.toISOString() });
  }

  // House recommendation: next step
  if (house.nextSteps) {
    recommendations.push({ id: `${idBase}-house`, type: 'house', content: `Next step for your house plan: ${house.nextSteps}`, createdAt: now.toISOString() });
  }

  // Calendar recommendation: today's events
  const todaysEvents = calendar.filter((ev) => new Date(ev.start).toDateString() === now.toDateString());
  if (todaysEvents.length > 0) {
    const eventTitles = todaysEvents.map((ev) => ev.title).join(', ');
    recommendations.push({ id: `${idBase}-calendar`, type: 'calendar', content: `Events today: ${eventTitles}.`, createdAt: now.toISOString() });
  }

  // Trading recommendation: highlight high conviction idea
  const highConviction = [...trading].sort((a, b) => b.conviction - a.conviction)[0];
  if (highConviction) {
    recommendations.push({ id: `${idBase}-trading`, type: 'trading', content: `Consider reviewing: ${highConviction.symbol} (conviction ${Math.round(highConviction.conviction * 100)}%).`, createdAt: now.toISOString() });
  }

  // Risk recommendation: highlight potential issue
  // Identify the nearest due task or overspending risk
  const upcomingTask = sortedTasks[0];
  let riskContent: string | null = null;
  if (overspending > 0) {
    riskContent = `Risk alert: you're overspending by $${overspending.toFixed(2)} this week.`;
  } else if (upcomingTask && upcomingTask.dueDate) {
    const due = new Date(upcomingTask.dueDate);
    const diffDays = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays <= 2) {
      riskContent = `Risk alert: upcoming deadline – ${upcomingTask.title} is due in ${diffDays} day${diffDays === 1 ? '' : 's'}.`;
    }
  }
  if (riskContent) {
    recommendations.push({ id: `${idBase}-risk`, type: 'risk' as any, content: riskContent, createdAt: now.toISOString() });
  }

  return recommendations;
}