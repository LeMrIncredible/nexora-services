import {
  MoneyData,
  HousePlanData,
  Task,
  Opportunity,
  TradingIdea,
  ConnectionsData,
  CalendarEvent,
  EmailSummary,
  MarketQuote,
  ChatMessage,
  Recommendation,
  Notification,
  DailyBrief,
  AutomationSettings,
} from '../types';

// Money seeds derived from the provided spreadsheet. This object acts
// as the initial state for the Money dashboard. Should you update your
// finances in the application, changes are persisted to localStorage.
export const moneySeed: MoneyData = {
  incomes: [
    { name: 'Brody', budget: 3250.0, actual: 2600.0 },
    { name: 'Mariah', budget: 4000.0, actual: 4000.0 },
  ],
  totalMonthlyIncomeBudget: 7250.0,
  totalMonthlyIncome: 6600.0,
  totalMonthlyExpensesBudget: 3593.01,
  totalMonthlyExpensesActual: 3883.01,
  weeklyBudget: 3593.01 / 4,
  weeklySpending: 3883.01 / 4,
  safeToSpend: 2716.99 / 4,
  moneyLeft: 2716.99,
  expenses: [
    { category: 'Electric', budget: 0.0, actual: 289.0 },
    { category: 'Internet', budget: 0.0, actual: 70.0 },
    { category: 'Cell Phone', budget: 260.0, actual: 232.0 },
    { category: 'Car Insurance', budget: 210.0, actual: 209.0 },
    { category: 'Car Payment', budget: 489.0, actual: 489.0 },
    { category: 'Student Loan', budget: 60.0, actual: 60.0 },
    { category: 'Gas', budget: 500.0, actual: 500.0 },
    { category: 'Daycare', budget: 588.0, actual: 588.0 },
    { category: 'Groceries', budget: 500.0, actual: 500.0 },
    { category: 'Spotify', budget: 27.4, actual: 27.4 },
    { category: 'Amazon', budget: 41.96, actual: 41.96 },
    { category: 'Zyn / Other', budget: 240.0, actual: 200.0 },
    { category: 'Camper Loan', budget: 676.65, actual: 676.65 },
  ],
};

// House plan seeds derived from the spreadsheet. Contains build
// milestones and high-level tracking for buying land and building a
// house. Feel free to edit these values from within the Settings page
// once the application is running.
export const houseSeed: HousePlanData = {
  stage: 'Saving for site work',
  progress: 61845.598 / 139387, // roughly 44.4% towards getting the camper inside
  target: 139387,
  current: 61845.598,
  milestones: [
    { item: 'Preconstruction + permits/design', chosenCost: 2000, extraLogged: 0, currentTotal: 2000, notes: 'Needed before site work' },
    { item: 'Sitework + driveway', chosenCost: 6000, extraLogged: 0, currentTotal: 6000, notes: 'Access and grade' },
    { item: 'Electric service', chosenCost: 5387, extraLogged: 0, currentTotal: 5387, notes: 'Power to site' },
    { item: 'Septic system', chosenCost: 14000, extraLogged: 0, currentTotal: 14000, notes: 'Wastewater' },
    { item: 'Drilled well', chosenCost: 15000, extraLogged: 0, currentTotal: 15000, notes: 'If needed' },
    { item: 'Post-frame shell structure', chosenCost: 97000, extraLogged: 0, currentTotal: 97000, notes: 'Shell before slab' },
    { item: 'Doors / openings', chosenCost: 10000, extraLogged: 0, currentTotal: 10000, notes: 'Overheads + man doors' },
    { item: 'Weather‑tight / insulation', chosenCost: 12000, extraLogged: 0, currentTotal: 12000, notes: 'Get dried in' },
    { item: 'Concrete floor later', chosenCost: 45000, extraLogged: 0, currentTotal: 45000, notes: 'After shell is up' },
    { item: 'Contingency reserve', chosenCost: 10000, extraLogged: 0, currentTotal: 10000, notes: 'Leave as reserve' },
  ],
  nextSteps: 'Continue saving and searching for land; finalize the build design; ensure permits and approvals are ready.',
  blockers: 'Need to secure land; need additional funds; coordinate with contractors.',
  timeline: [
    { name: 'Preconstruction & Design', targetDate: '2026-04-15', status: 'completed' },
    { name: 'Land Purchase', targetDate: '2026-06-30', status: 'pending' },
    { name: 'Site Preparation', targetDate: '2026-08-15', status: 'pending' },
    { name: 'Shell Construction', targetDate: '2026-12-15', status: 'pending' },
  ],
};

// Seed tasks that populate the Tasks dashboard. These tasks are meant
// to reflect priorities across different areas of life. Each task has
// an identifier so that it can be updated or removed within the
// application.
export const tasksSeed: Task[] = [
  { id: '1', title: 'Review weekly budget', category: 'Money', dueDate: '2026-03-22', priority: 'high', status: 'todo' },
  { id: '2', title: 'Pay cell phone bill', category: 'Money', dueDate: '2026-03-25', priority: 'medium', status: 'todo' },
  { id: '3', title: 'Research land plots in Maine', category: 'House', dueDate: '2026-03-30', priority: 'high', status: 'todo' },
  { id: '4', title: 'Call builder to discuss design', category: 'House', dueDate: '2026-03-28', priority: 'medium', status: 'todo' },
  { id: '5', title: 'Finish client deliverables', category: 'Work', dueDate: '2026-03-24', priority: 'high', status: 'in-progress' },
  { id: '6', title: 'Workout', category: 'Personal', dueDate: '2026-03-21', priority: 'medium', status: 'todo' },
];

// Seed opportunities. Opportunities represent ways to bring in extra
// income. They are scored with estimated value, effort, and urgency
// which can be used to rank the best opportunity at any given time.
export const opportunitiesSeed: Opportunity[] = [
  {
    id: 'op1',
    title: 'Freelance web development project',
    type: 'Freelance',
    estimatedValue: 5000,
    effort: 8,
    urgency: 9,
    status: 'todo',
    notes: 'Client awaiting proposal',
  },
  {
    id: 'op2',
    title: 'Sell unused equipment',
    type: 'Resale',
    estimatedValue: 500,
    effort: 3,
    urgency: 7,
    status: 'in-progress',
    notes: 'Clean and list items online',
  },
  {
    id: 'op3',
    title: 'Rent spare room',
    type: 'Rental',
    estimatedValue: 1200,
    effort: 5,
    urgency: 4,
    status: 'todo',
    notes: 'Advertise on local listing sites',
  },
];

// Seed trading ideas. These watchlist items contain simple trade
// parameters; they do not execute any trades but help you keep track
// of market opportunities.
export const tradingSeed: TradingIdea[] = [
  {
    id: 'ti1',
    symbol: 'AAPL',
    entry: 170,
    target: 185,
    stop: 160,
    conviction: 0.7,
    notes: 'Strong quarterly results',
  },
  {
    id: 'ti2',
    symbol: 'TSLA',
    entry: 260,
    target: 300,
    stop: 240,
    conviction: 0.5,
    notes: 'High volatility; position sizing important',
  },
  {
    id: 'ti3',
    symbol: 'SPY',
    entry: 450,
    target: 460,
    stop: 440,
    conviction: 0.6,
    notes: 'Broad market exposure',
  },
];

// -----------------------------------------------------------------------------
// NEW SEEDS FOR THE BRAIN LAYER
//
// These seeds initialise the additional pieces of state introduced for the
// connections/integrations layer, calendar and email awareness, live market
// data, chat history and generated recommendations. In a production system
// these would be empty until the user connects services. Here we provide
// minimal sample data to illustrate the data shapes.

// Default connections configuration. All services start disabled and not
// connected. API keys are empty strings. The status field reflects the
// current connection state for each integration.
export const connectionsSeed: ConnectionsData = {
  openai: { enabled: false, status: 'not_connected', key: '' },
  gmail: { enabled: false, status: 'not_connected', key: '' },
  calendar: { enabled: false, status: 'not_connected', key: '' },
  market: { enabled: false, status: 'not_connected', key: '' },
  verse: { enabled: false, status: 'not_connected', key: '' },
  weather: { enabled: false, status: 'not_connected', key: '' },
  // Google Sheets integration starts disabled. It stores sheetId and tokens when connected.
  sheet: { enabled: false, status: 'not_connected' },
};

// Initial notifications list is empty. Notifications will be generated by
// the automation engine as the user’s data changes over time.
export const notificationsSeed: Notification[] = [];

// The daily brief is generated each morning by the automation engine. Until
// then it is null. We store it separately so it can be referenced by
// the home page and assistant.
export const dailyBriefSeed: DailyBrief | null = null;

// Default automation settings. Daily automation is enabled and periodic
// updates occur every 60 minutes. Notifications are enabled by default.
export const automationSettingsSeed: AutomationSettings = {
  dailyEnabled: true,
  periodicEnabled: true,
  periodicInterval: 60,
  notificationsEnabled: true,
};

// Sample calendar events. In a real integration these would come from
// Google Calendar or another source. The times should be ISO strings.
export const calendarSeed: CalendarEvent[] = [
  {
    id: 'cal1',
    title: 'Team Standup Meeting',
    start: new Date().toISOString(),
    end: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
    location: 'Zoom',
    description: 'Daily sync with the team',
  },
  {
    id: 'cal2',
    title: 'Dentist Appointment',
    start: new Date(Date.now() + 3 * 60 * 60 * 1000).toISOString(),
    end: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
    location: 'Downtown Dental',
  },
];

// Sample email summaries. These are intentionally short and non-sensitive.
export const emailsSeed: EmailSummary[] = [
  {
    id: 'email1',
    subject: 'Invoice due in 3 days',
    snippet: 'Reminder: your electricity bill is due soon. Please make a payment to avoid late fees.',
    receivedAt: new Date().toISOString(),
    from: 'billing@exampleutility.com',
  },
  {
    id: 'email2',
    subject: 'Project kickoff tomorrow',
    snippet: 'We look forward to kicking off the new project tomorrow at 10 AM.',
    receivedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    from: 'client@agency.com',
  },
];

// Sample market data. Normally this would update frequently from a data API.
export const marketSeed: MarketQuote[] = [
  { symbol: 'AAPL', price: 174.23, change: 1.23, updatedAt: new Date().toISOString() },
  { symbol: 'TSLA', price: 276.12, change: -2.34, updatedAt: new Date().toISOString() },
  { symbol: 'SPY', price: 459.67, change: 0.45, updatedAt: new Date().toISOString() },
];

// Initial chat history. An empty array signals a new conversation. If you
// wanted to seed with a welcome message you could add one here.
export const chatSeed: ChatMessage[] = [];

// Initial recommendations. Empty at first; the engine will populate this.
export const recommendationsSeed: Recommendation[] = [];