// utils/persistence.ts
// Central persistence helper functions for Life OS
//
// This module provides utilities to load and save pieces of application
// state from localStorage in a versioned manner. A small metadata wrapper
// containing a `_version` field is stored alongside the real data. When
// loading, if the version does not match the current `DATA_VERSION` or
// parsing fails, the provided seed value is returned instead. Errors
// encountered during parsing or saving are caught and logged to avoid
// interrupting the user experience.

export const DATA_VERSION = '1.0';

/**
 * Load a value from localStorage. If the stored object contains the
 * expected `_version` and `data` properties matching the current
 * `DATA_VERSION`, the parsed data is returned. Otherwise, the supplied
 * seed value is returned and the invalid entry is removed.
 *
 * @param key The localStorage key to read from
 * @param seed A fallback value to use when nothing is stored or parsing fails
 */
export function loadState<T>(key: string, seed: T): T {
  if (typeof window === 'undefined') return seed;
  const raw = localStorage.getItem(key);
  if (!raw) return seed;
  try {
    const parsed = JSON.parse(raw);
    if (parsed && parsed._version === DATA_VERSION && 'data' in parsed) {
      return parsed.data as T;
    }
  } catch (err) {
    console.error(`Failed to parse persisted data for key "${key}"`, err);
  }
  // Remove stale or corrupt entries
  try {
    localStorage.removeItem(key);
  } catch (err) {
    console.error(`Failed to remove invalid data for key "${key}"`, err);
  }
  return seed;
}

/**
 * Save a value to localStorage with version metadata. The data is
 * serialised along with a `_version` property so that future schema
 * migrations can detect incompatible entries. Any errors during
 * serialisation or writing are caught and logged.
 *
 * @param key The localStorage key to write to
 * @param data The value to persist
 */
export function saveState<T>(key: string, data: T) {
  if (typeof window === 'undefined') return;
  const payload = { _version: DATA_VERSION, data };
  try {
    localStorage.setItem(key, JSON.stringify(payload));
  } catch (err) {
    console.error(`Failed to persist data for key "${key}"`, err);
  }
}