/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Removed experimental.appDir for Next.js 14. The app directory is now
  // enabled by default, so this configuration is unnecessary and
  // triggers a warning.
};

module.exports = nextConfig;