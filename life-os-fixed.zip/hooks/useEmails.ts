import { useEffect } from 'react';
import { useData } from '../app/context';
import { fetchEmails } from '../utils/services/email';

/**
 * Hook to load recent email summaries into the global state. When the
 * Gmail integration status changes, new summaries are fetched. Components
 * can then access emails via useData().
 */
export function useEmails() {
  const { connections, setEmails } = useData();

  useEffect(() => {
    async function load() {
      const list = await fetchEmails(connections);
      setEmails(list);
    }
    load();
  }, [connections.gmail?.enabled, connections.gmail?.status]);
}