import { useEffect } from 'react';
import { useData } from '../app/context';
import { generateDailyBrief } from '../utils/services/dailyBrief';
import { generateNotifications } from '../utils/services/notifications';
import { generateRecommendations } from '../utils/recommendations';
import { fetchMarketQuotes } from '../utils/services/market';
import { fetchCalendarEvents } from '../utils/services/calendar';
import { fetchVerse } from '../utils/services/verse';
import { fetchWeather } from '../utils/services/weather';

/**
 * useAutomation sets up scheduled tasks for Life OS. It runs a daily job to
 * generate a daily brief, update recommendations and produce notifications.
 * It also runs periodic tasks to refresh live data from integrations. The
 * schedule is configurable via automationSettings in the global context.
 * The hook should be called once at the app root to ensure tasks run in the
 * background. It uses localStorage to track when the last daily job ran.
 */
export function useAutomation() {
  const {
    money,
    tasks,
    opportunities,
    house,
    calendarEvents,
    trading,
    connections,
    notifications,
    setNotifications,
    dailyBrief,
    setDailyBrief,
    automationSettings,
    setAutomationSettings,
    lastUpdated,
    setLastUpdated,
    setMarket,
    setCalendarEvents,
    setRecommendations,
  } = useData();

  // Run the daily job on mount and whenever dependencies change. The job
  // runs if daily automation is enabled and the last run date is not today.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (!automationSettings.dailyEnabled) return;
    const todayStr = new Date().toDateString();
    const lastRun = lastUpdated['dailyBrief'];
    const lastDateStr = lastRun ? new Date(lastRun).toDateString() : null;
    if (lastDateStr !== todayStr) {
      // Generate daily brief
      const brief = generateDailyBrief(money, tasks, opportunities, house, calendarEvents);
      setDailyBrief(brief);
      // Generate notifications
      if (automationSettings.notificationsEnabled) {
        const newNotifs = generateNotifications(money, tasks, opportunities, house, calendarEvents);
        // Append new notifications; ensure uniqueness by id (can duplicate due to multiple triggers). We'll just append.
        setNotifications([...notifications, ...newNotifs]);
      }
      // Generate fresh recommendations
      const recs = generateRecommendations(money, house, tasks, opportunities, trading, calendarEvents);
      setRecommendations(recs);
      // Update last run timestamp
      setLastUpdated({ ...lastUpdated, dailyBrief: new Date().toISOString() });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [automationSettings.dailyEnabled, money, tasks, opportunities, house, calendarEvents, automationSettings.notificationsEnabled]);

  // Periodic refresh tasks
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (!automationSettings.periodicEnabled) return;
    // Define refresh function outside to avoid stale closures
    const runPeriodic = async () => {
      const now = new Date().toISOString();
      // Refresh market data if enabled
      if (connections.market?.enabled) {
        try {
          const symbols = trading.map((t) => t.symbol);
          const quotes = await fetchMarketQuotes(connections, symbols);
          setMarket(quotes);
          setLastUpdated((prev) => ({ ...prev, market: now }));
        } catch (err) {
          console.error('Periodic market update failed', err);
        }
      }
      // Refresh calendar events if enabled
      if (connections.calendar?.enabled) {
        try {
          const events = await fetchCalendarEvents(connections);
          setCalendarEvents(events);
          setLastUpdated((prev) => ({ ...prev, calendar: now }));
        } catch (err) {
          console.error('Periodic calendar update failed', err);
        }
      }
      // Refresh verse if enabled; no global state, so just update timestamp
      if (connections.verse?.enabled) {
        try {
          await fetchVerse(connections);
          setLastUpdated((prev) => ({ ...prev, verse: now }));
        } catch (err) {
          console.error('Periodic verse update failed', err);
        }
      }
      // Refresh weather if enabled; no global state, just update timestamp
      if (connections.weather?.enabled) {
        try {
          await fetchWeather(connections);
          setLastUpdated((prev) => ({ ...prev, weather: now }));
        } catch (err) {
          console.error('Periodic weather update failed', err);
        }
      }
    };
    // Immediately run periodic tasks once on mount
    runPeriodic();
    const intervalMs = (automationSettings.periodicInterval || 60) * 60 * 1000;
    const timer = setInterval(runPeriodic, intervalMs);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [automationSettings.periodicEnabled, automationSettings.periodicInterval, connections, trading]);

  return null;
}