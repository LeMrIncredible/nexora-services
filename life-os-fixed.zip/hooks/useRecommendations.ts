import { useEffect } from 'react';
import { useData } from '../app/context';
import { generateRecommendations } from '../utils/recommendations';

/**
 * Hook that recomputes recommendations whenever the underlying data changes.
 * It stores the new recommendations into the global state. Components can
 * subscribe to recommendations via useData(). This provides a simple rule
 * based guidance layer until more advanced AI logic is available.
 */
export function useRecommendations() {
  const {
    money,
    house,
    tasks,
    opportunities,
    trading,
    calendarEvents,
    setRecommendations,
  } = useData();

  useEffect(() => {
    const recs = generateRecommendations(money, house, tasks, opportunities, trading, calendarEvents);
    setRecommendations(recs);
  }, [money, house, tasks, opportunities, trading, calendarEvents]);
}