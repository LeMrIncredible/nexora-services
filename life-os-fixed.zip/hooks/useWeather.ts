import { useEffect, useState } from 'react';
import { useData } from '../app/context';
import { fetchWeather } from '../utils/services/weather';

/**
 * Hook to fetch the current weather using the weather integration. When the
 * integration is enabled and the API key changes, the weather is reloaded.
 * Returns a weather object containing temperature, condition and location.
 */
export function useWeather() {
  const { connections } = useData();
  const [weather, setWeather] = useState<{ temp: number; condition: string; location: string } | null>(null);

  useEffect(() => {
    async function load() {
      const w = await fetchWeather(connections);
      setWeather(w);
    }
    load();
  }, [connections.weather?.enabled]);

  return weather;
}