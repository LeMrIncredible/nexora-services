import { useEffect } from 'react';
import { useData } from '../app/context';
import { fetchMarketQuotes } from '../utils/services/market';

/**
 * Hook to load live market quotes into the global state. When the market
 * integration is enabled or the API key changes, new quotes are fetched.
 * Components can then access market data via useData().
 */
export function useMarket() {
  const { connections, setMarket, trading } = useData();

  useEffect(() => {
    async function load() {
      // Extract symbols from trading ideas for live quotes
      const symbols = trading.map((t) => t.symbol);
      const quotes = await fetchMarketQuotes(connections, symbols);
      setMarket(quotes);
    }
    load();
    // Dependencies: reload when integration is toggled or watchlist changes
  }, [connections.market?.enabled, trading]);
}