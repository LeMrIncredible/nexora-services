import { useEffect, useState } from 'react';
import { useData } from '../app/context';
import { fetchVerse } from '../utils/services/verse';

/**
 * Hook to retrieve the verse of the day based on the current connections
 * settings. It fetches a verse when the component mounts or when the
 * verse integration toggles. Result is cached in component state.
 */
export function useVerse() {
  const { connections } = useData();
  const [verse, setVerse] = useState<{ text: string; reference: string } | null>(null);

  useEffect(() => {
    async function load() {
      const v = await fetchVerse(connections);
      setVerse(v);
    }
    load();
  }, [connections.verse?.enabled]);

  return verse;
}