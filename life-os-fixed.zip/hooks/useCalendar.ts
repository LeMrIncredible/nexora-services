import { useEffect } from 'react';
import { useData } from '../app/context';
import { fetchCalendarEvents } from '../utils/services/calendar';

/**
 * Hook to load upcoming calendar events into the global state. Whenever the
 * calendar integration is toggled on/off or its status changes, events are
 * reloaded. Components can then access calendarEvents via useData().
 */
export function useCalendar() {
  const { connections, setCalendarEvents, lastUpdated, setLastUpdated } = useData();

  useEffect(() => {
    async function load() {
      const events = await fetchCalendarEvents(connections);
      setCalendarEvents(events);
      // Update last updated timestamp when events are loaded and calendar is connected
      if (connections.calendar?.enabled) {
        setLastUpdated({ ...lastUpdated, calendar: new Date().toISOString() });
      }
    }
    load();
  }, [connections.calendar?.enabled, connections.calendar?.status]);
}