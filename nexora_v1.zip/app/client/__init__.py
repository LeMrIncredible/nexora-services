"""Client blueprint package."""

from .routes import client_bp  # noqa: F401