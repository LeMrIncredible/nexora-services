"""Admin blueprint package."""

from .routes import admin_bp  # noqa: F401