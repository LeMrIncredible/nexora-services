## Smart Booking & Reminders

The Smart Booking & Reminders automation eliminates the back‑and‑forth of scheduling by letting customers choose from your actual availability and ensuring they show up.  It integrates with your calendar and messaging channels to provide a seamless booking experience.

### How it works

1. **Configuration** – Reads `CLIENT_NAME` from environment variables to personalise messages.  For a complete implementation you would also provide Google Calendar credentials (see `.env.example`) to read and write events.
2. **Select slot** – For demonstration purposes this automation randomly selects a slot within the next seven days at 10 AM.  In production you would query your real availability from Google Calendar or another system.
3. **Confirm** – Constructs a confirmation message that includes the chosen date and time along with the business name.  You could extend this to create the calendar event and send an email or SMS confirmation.
4. **Reminder scheduling** – Schedules reminder messages to be sent 24 hours before the appointment.  This is simulated here but would be implemented using a cron job or a scheduling service in production.
5. **Logging** – Every invocation is logged to both the console and a file under `logs/smart-booking/` using the shared logger.
6. **Return** – Returns an object with `status`, `name` and `message` summarising the booking confirmation.

### Configuration

| Variable | Required | Description |
| --- | --- | --- |
| `CLIENT_NAME` | ✓ | Name of your business used in confirmation messages. |
| `AUTOMATION_SMART_BOOKING_ENABLED` | – | Enable or disable this automation. |

Optional variables for calendar and email integrations are documented in `.env.example`.

### Running

Execute this automation manually with:

```bash
node automations/smart-booking/index.js
```

Each run logs to `logs/smart-booking/` and prints a confirmation message.  Replace the simulated slot selection with real calendar logic when integrating.

### Testing

Use the test runner to perform five consecutive successful runs:

```bash
node run-tests.js --automation smart-booking
```

Results and log file references will be stored in `automations/smart-booking/TEST_REPORT.md`.
